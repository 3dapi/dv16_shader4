// Implementation of the CTexDistort class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CTexDistort::CTexDistort()
{
	m_pDev	= NULL;

	m_pPrt	= NULL;

	m_pTrnd	= NULL;
}


CTexDistort::~CTexDistort()
{
	Destroy();
}


INT CTexDistort::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;


	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrnd, m_pDev)))
		return -1;


	m_pPrt = new CMcParticle;
	m_pPrt->Create(m_pDev);

	return 0;
}

void CTexDistort::Destroy()
{
	SAFE_DELETE(	m_pTrnd	);
	SAFE_DELETE(	m_pPrt	);
}


INT CTexDistort::Restore()
{
	return m_pTrnd->OnResetDevice();
}

void CTexDistort::Invalidate()
{
	m_pTrnd->OnLostDevice();
}


INT CTexDistort::FrameMove()
{
	// ��ƼŬ �����͸� �����Ѵ�.
	m_pPrt->SetTimeEps(g_pApp->m_fElapsedTime);
	m_pPrt->FrameMove();

	// ��ƼŬ�� ������ �ؽ�ó�� �׸���.
	m_pTrnd->BeginScene();

	m_pDev->Clear( 0L
					, NULL
					, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
					, D3DXCOLOR(0.5F,0.5F,0,1)
					, 1.0f
					, 0L
					);


	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


	m_pPrt->Render();

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);

	
	m_pTrnd->EndScene();


	return 0;
}


void CTexDistort::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);



	struct Tvtx
	{
		FLOAT	p[4];
		FLOAT	u,v;
	} pVtx[4]	=
	{
		{   0,   0,  0,  1,  0, 0},
		{ 360,   0,  0,  1,  1, 0},
		{ 360, 270,  0,  1,  1, 1},
		{   0, 270,  0,  1,  0, 1},
	};

	PDTX	pTex = (PDTX)m_pTrnd->GetTexture();

	m_pDev->SetTexture(0, pTex);
	m_pDev->SetFVF(D3DFVF_XYZRHW|D3DFVF_TEX1);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(Tvtx));

	m_pDev->SetTexture(0, NULL);






	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);


	m_pPrt->Render();

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}



PDTX CTexDistort::GetTexture()
{
	return (PDTX)m_pTrnd->GetTexture();
}
