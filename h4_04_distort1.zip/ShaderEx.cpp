// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	
	m_pDst	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0, 0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1, 0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1, 1, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0, 1, D3DXCOLOR(0,0,1,1));



	SAFE_NEWCREATE1(m_pDst, CTexDistort, m_pDev);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_DELETE(	m_pDst	);
}


INT CShaderEx::Restore()
{
	m_pDst->Restore();
	return 0;
}

void CShaderEx::Invalidate()
{
	m_pDst->Invalidate();
}


INT CShaderEx::FrameMove()
{
	m_pDst->FrameMove();
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	m_pDev->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);


	m_pDst->Render();
}


