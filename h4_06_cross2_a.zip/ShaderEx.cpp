// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning(disable: 4244)


#include "_StdAfx.h"


static const int MAX_SAMP	= 8;


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pFVF		= NULL;
	m_pEft		= NULL;

	m_pTexS		= NULL;
	m_pTexL		= NULL;

	m_pTrndX	= NULL;
	m_pTrndY	= NULL;

	for(int i=0; i<6; ++i)
		m_pTrndC[i] = NULL;

	m_pTrndS	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1( -1, 1,  0,  0, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1(  1, 1,  0,  1, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1(  1,-1,  0,  1, 1, D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1( -1,-1,  0,  0, 1, D3DXCOLOR(1,1,1,1));



	char	sShaderFile[]="data/hlsl.fx";
	LPD3DXBUFFER	pError	= NULL;
	DWORD		dFlag=0;

	#if defined( _DEBUG ) || defined( DEBUG )
	dFlag |= D3DXSHADER_DEBUG;
	#endif

	// ������
	hr = D3DXCreateEffectFromFile(
								  m_pDev
								, sShaderFile
								, NULL
								, NULL
								, dFlag
								, NULL
								, &m_pEft
								, &pError);
	if(FAILED(hr))
	{
		MessageBox(GetActiveWindow()
					, (char*)pError->GetBufferPointer()
					, "Error", 0);
		return -1;
	}
	
	// ���� ���� ����
	D3DVERTEXELEMENT9 pVertexElement[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, pVertexElement);
	m_pDev->CreateVertexDeclaration(pVertexElement, &m_pFVF);








	m_fTxW = 256;
	m_fTxH = m_fTxW;

	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndX, m_pDev, m_fTxW, m_fTxH)))	// Bluring X �� �ؽ�ó
		return -1;

	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndY, m_pDev, m_fTxW, m_fTxH)))	// Bluring Y �� �ؽ�ó
		return -1;

	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndS, m_pDev, m_fTxW, m_fTxH)))	// Cross Texture All
		return -1;

	for(INT i=0; i<6; ++i)
	{
		if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndC[i], m_pDev, m_fTxW, m_fTxH)))	// Cross Texture
			return -1;
	}



//	if(FAILED(LcD3D_CreateRenderTarget("HDR16", &m_pTrndX, m_pDev, m_fTxW, m_fTxH)))	// Bluring X �� �ؽ�ó
//		return -1;
//
//	if(FAILED(LcD3D_CreateRenderTarget("HDR16", &m_pTrndY, m_pDev, m_fTxW, m_fTxH)))	// Bluring Y �� �ؽ�ó
//		return -1;
//
//	if(FAILED(LcD3D_CreateRenderTarget("HDR16", &m_pTrndS, m_pDev, m_fTxW, m_fTxH)))	// Cross Texture All
//		return -1;
//
//	for(int i=0; i<6; ++i)
//	{
//		if(FAILED(LcD3D_CreateRenderTarget("HDR16", &m_pTrndC[i], m_pDev, m_fTxW, m_fTxH)))	// Cross Texture
//			return -1;
//	}


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_RELEASE(	m_pFVF		);

	SAFE_DELETE(	m_pTrndX	);
	SAFE_DELETE(	m_pTrndY	);

	SAFE_DELETE(	m_pTrndS	);

	for(int i=0; i<6; ++i)
	{
		SAFE_DELETE(	m_pTrndC[i]	);
	}
}


INT CShaderEx::FrameMove()
{
	HRESULT hr;

	INT		i=0, j=0;
	PDTX	pTx =NULL;


	// 1. Luminescence Texture�� ����Ѵ�.
	pTx = m_pTexL;


	// 2. ��ҵ� �ؽ�ó�� Luminescence�� ���� �κ��� �׸���.
	m_pTrndY->BeginScene();
		hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
		
		hr = m_pDev->SetVertexDeclaration(m_pFVF);
		hr = m_pEft->SetTechnique("TechCross");
		hr = m_pEft->SetTexture("m_TxDif", pTx);
		hr = m_pEft->SetFloat("m_TexW", m_fTxW);
		hr = m_pEft->SetFloat("m_TexH", m_fTxH);
		
		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(0);

		hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndY->EndScene();



	// 3. ��ҵ� �ؽ�ó�� ������.
	for(i=0; i<2; ++i)
	{
		m_pTrndX->BeginScene();

			pTx = (PDTX)m_pTrndY->GetTexture();
			hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
			
			hr = m_pDev->SetVertexDeclaration(m_pFVF);

			hr = m_pEft->SetTechnique("TechBlur");
			hr = m_pEft->SetTexture("m_TxDif", pTx);
			hr = m_pEft->SetFloat("m_TexW", m_fTxW);
			hr = m_pEft->SetFloat("m_TexH", m_fTxH);
			
			hr = m_pEft->Begin(NULL, 0);
			hr = m_pEft->BeginPass(0);

				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

			m_pEft->EndPass();
			m_pEft->End();

		m_pTrndX->EndScene();


		m_pTrndY->BeginScene();

			pTx = (PDTX)m_pTrndX->GetTexture();
			hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
			
			hr = m_pDev->SetVertexDeclaration(m_pFVF);
			hr = m_pEft->SetTechnique("TechBlur");
			hr = m_pEft->SetTexture("m_TxDif", pTx);
			hr = m_pEft->SetFloat("m_TexW", m_fTxW);
			hr = m_pEft->SetFloat("m_TexH", m_fTxH);
			
			hr = m_pEft->Begin(NULL, 0);
			hr = m_pEft->BeginPass(1);

				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

			m_pEft->EndPass();
			m_pEft->End();

		m_pTrndY->EndScene();
	}


	D3DXMATRIX mtViw;
	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);

	mtViw._41 = 0;
	mtViw._42 = 0;
	mtViw._43 = 0;

	D3DXQUATERNION q;
	FLOAT	fTime=GetTickCount()*0.001f;

	D3DXQuaternionRotationMatrix(&q, &mtViw);

	float fc= acosf(q.w*0.99f) * 24.f + fTime*0.1f;



	//4. Cross�� �����.
	for(j=0; j<6; ++j)
	{
		IrenderTarget*	pTrnd = m_pTrndC[j];

		float	fTheta = (fc+2.f * j * D3DX_PI)/6;

//		float	rA = 7.f;
//		float	rB = 12.f;

		float	rA = 5.5f;
		float	rB = 8.5f;

		float	x = rA * cosf(fTheta)/m_fTxW;
		float	y = rB * sinf(fTheta)/m_fTxH;

		double	fDelta= 0.01;
		D3DXVECTOR4	StarVal[MAX_SAMP];

		float	fStarPow=1.3f;


		for(int k=0; k<MAX_SAMP; ++k)
		{
			StarVal[k].x = x*k;
			StarVal[k].y = y*k;
			StarVal[k].z = expf(-k*k/10);
		}

		pTrnd->BeginScene();

			pTx = (PDTX)m_pTrndY->GetTexture();
			hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
			
			hr = m_pDev->SetVertexDeclaration(m_pFVF);
			hr = m_pEft->SetTechnique("TechCross");

			hr = m_pEft->SetTexture("m_TxDif", pTx);
			hr = m_pEft->SetFloat("m_TexW", m_fTxW);
			hr = m_pEft->SetFloat("m_TexH", m_fTxH);
			hr = m_pEft->SetVectorArray("m_StarVal", StarVal, MAX_SAMP);
			hr = m_pEft->SetFloat("m_StarPow", fStarPow);

			hr = m_pEft->Begin(NULL, 0);

			hr = m_pEft->BeginPass(1);
				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

				hr = m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
				hr = m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
				hr = m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
				hr = m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
			m_pEft->EndPass();
			
			hr = m_pEft->BeginPass(2);
				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
			m_pEft->EndPass();

			hr = m_pEft->BeginPass(3);
				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
			m_pEft->EndPass();

			m_pEft->End();

			hr = m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
			hr = m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);


		pTrnd->EndScene();
	}


	//5. ��� ��Ÿ�� �ϳ��� ��ģ��.
	m_pTrndS->BeginScene();

		hr = m_pDev->SetVertexDeclaration(m_pFVF);
		hr = m_pEft->SetTechnique("TechCross");

		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(4);

			for(j=0; j<6; ++j)
			{
				IrenderTarget*	pTrnd = m_pTrndC[j];
				pTx = (PDTX)pTrnd->GetTexture();
				hr = m_pDev->SetTexture(j, pTx);
			}

			hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndS->EndScene();



	//6. ��ģ �ؽ��� ������
	m_pTrndY->BeginScene();

		pTx = (PDTX)m_pTrndS->GetTexture();
		hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
		
		hr = m_pDev->SetVertexDeclaration(m_pFVF);
		hr = m_pEft->SetTechnique("TechBlur");

		hr = m_pEft->SetTexture("m_TxDif", pTx);
		hr = m_pEft->SetFloat("m_TexW", m_fTxW);
		hr = m_pEft->SetFloat("m_TexH", m_fTxH);
		
		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(1);

			hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndY->EndScene();



	// ��ҵ� �ؽ�ó�� ������.
	for(i=0; i<2; ++i)
	{
		m_pTrndX->BeginScene();

			pTx = (PDTX)m_pTrndY->GetTexture();
			hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
			
			hr = m_pDev->SetVertexDeclaration(m_pFVF);
			hr = m_pEft->SetTechnique("TechBlur");

			hr = m_pEft->SetTexture("m_TxDif", pTx);
			hr = m_pEft->SetFloat("m_TexW", m_fTxW);
			hr = m_pEft->SetFloat("m_TexH", m_fTxH);
			
			hr = m_pEft->Begin(NULL, 0);
			hr = m_pEft->BeginPass(0);

				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

			m_pEft->EndPass();		
			m_pEft->End();

		m_pTrndX->EndScene();


		m_pTrndY->BeginScene();

			pTx = (PDTX)m_pTrndX->GetTexture();
			hr = m_pDev->Clear( 0L, NULL, 0x01L | 0x02L, 0, 1.0f, 0L );
			
			hr = m_pDev->SetVertexDeclaration(m_pFVF);
			hr = m_pEft->SetTechnique("TechBlur");

			hr = m_pEft->SetTexture("m_TxDif", pTx);
			hr = m_pEft->SetFloat("m_TexW", m_fTxW);
			hr = m_pEft->SetFloat("m_TexH", m_fTxH);
			
			hr = m_pEft->Begin(NULL, 0);
			hr = m_pEft->BeginPass(1);

				hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

			m_pEft->EndPass();
			m_pEft->End();

		m_pTrndY->EndScene();
	}

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	return 0;
}


void CShaderEx::Render()
{
	INT		i=0;
	HRESULT hr=0;
	static D3DXMATRIX mtI(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);

	for(i=0; i<8; ++i)
	{
		hr = m_pDev->SetSamplerState(i,D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
		hr = m_pDev->SetSamplerState(i,D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
		hr = m_pDev->SetSamplerState(i,D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		hr = m_pDev->SetSamplerState(i,D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		hr = m_pDev->SetSamplerState(i,D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}


	m_pDev->SetVertexDeclaration(m_pFVF);

	hr = m_pEft->SetTechnique("TechRnd");
	hr = m_pDev->SetTexture(0, m_pTexS);
	hr = m_pDev->SetTexture(1, (PDTX)m_pTrndS->GetTexture());
			
	hr = m_pEft->Begin(NULL, 0);
	hr = m_pEft->BeginPass(0);

		hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

#if 0
	PDTX			pTex;
	VtxDUV1			pVtx[4];		// Vertex Buffer

	pVtx[0] = VtxDUV1( -1.0F, 1.0F,  0,    0, 0);
	pVtx[1] = VtxDUV1( -0.6F, 1.0F,  0,    1, 0);
	pVtx[2] = VtxDUV1( -0.6F, 0.6F,  0,    1, 1);
	pVtx[3] = VtxDUV1( -1.0F, 0.6F,  0,    0, 1);

	m_pDev->SetFVF(VtxDUV1::FVF);

// ��ü ���
	m_pDev->SetTexture(0, m_pTexS);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(VtxDUV1));


// ���ֵ� ���
	pVtx[0] = VtxDUV1( -1.0F, 0.6F,  0,    0, 0);
	pVtx[1] = VtxDUV1( -0.6F, 0.6F,  0,    1, 0);
	pVtx[2] = VtxDUV1( -0.6F, 0.2F,  0,    1, 1);
	pVtx[3] = VtxDUV1( -1.0F, 0.2F,  0,    0, 1);

	m_pDev->SetTexture(0, m_pTexL);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(VtxDUV1));

	
// ũ�ν� ���� ���
	FLOAT ffW = 0.4F;
	pVtx[0].p.x = -1.0F;
	pVtx[1].p.x = -0.6F;
	pVtx[2].p.x = -0.6F;
	pVtx[3].p.x = -1.0F;

	for(i=0; i<3; ++i)
	{
		pVtx[0].p.y =  0.2F - (i + 0) * ffW;
		pVtx[1].p.y =  0.2F - (i + 0) * ffW;
		pVtx[2].p.y =  0.2F - (i + 1) * ffW;
		pVtx[3].p.y =  0.2F - (i + 1) * ffW;

		pTex = (PDTX)m_pTrndC[i]->GetTexture();
		m_pDev->SetTexture(0, pTex);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(VtxDUV1));
	}

	pVtx[0].p.x = -0.6F;
	pVtx[1].p.x = -0.2F;
	pVtx[2].p.x = -0.2F;
	pVtx[3].p.x = -0.6F;

	for(i=3; i<5; ++i)
	{
		pVtx[0].p.y =  0.2F - (i-3 + 0) * ffW;
		pVtx[1].p.y =  0.2F - (i-3 + 0) * ffW;
		pVtx[2].p.y =  0.2F - (i-3 + 1) * ffW;
		pVtx[3].p.y =  0.2F - (i-3 + 1) * ffW;

		pTex = (PDTX)m_pTrndC[i]->GetTexture();
		m_pDev->SetTexture(0, pTex);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(VtxDUV1));
	}


	// star all
	pVtx[0].p.y =  0.2F - (i-3 + 0) * ffW;
	pVtx[1].p.y =  0.2F - (i-3 + 0) * ffW;
	pVtx[2].p.y =  0.2F - (i-3 + 1) * ffW;
	pVtx[3].p.y =  0.2F - (i-3 + 1) * ffW;

	pTex = (PDTX)m_pTrndY->GetTexture();
	m_pDev->SetTexture(0, pTex);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(VtxDUV1));

#endif

	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
	
	for(i=0; i<8; ++i)
	{
		hr = m_pDev->SetSamplerState(i,D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		hr = m_pDev->SetSamplerState(i,D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	}
}



INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	m_pTrndX->OnResetDevice();
	m_pTrndY->OnResetDevice();

	for(int i=0; i<6; ++i)
		m_pTrndC[i]->OnResetDevice();

	m_pTrndS->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();

	m_pTrndX->OnLostDevice();
	m_pTrndY->OnLostDevice();

	for(int i=0; i<6; ++i)
		m_pTrndC[i]->OnLostDevice();

	m_pTrndS->OnLostDevice();
}


void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTexS = pTx;
}


void CShaderEx::SetLuminescenceTexture(PDTX pTx)
{
	m_pTexL = pTx;
}

