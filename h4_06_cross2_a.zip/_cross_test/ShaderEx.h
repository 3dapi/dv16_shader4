// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DVERTEXSHADER9				PDVS;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef	ID3DXEffect*						PDEF;




enum
{
	BLUR_MAX	= 8,
	CROSS_MAX	= 6,
};


class CShaderEx
{
public:
	struct VtxDUV1
	{
		VEC3	p;
		DWORD	d;
		FLOAT	u,v;
		
		VtxDUV1()	: p(0,0,0),d(0xFFFFFFFF),u(0),v(0){}
		VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
				,FLOAT U,FLOAT V, DWORD D=0XFFFFFFFF):p(X,Y,Z),u(U),v(V),d(D){}

		enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};

public:
	PDEV			m_pDev;					// Device
	PDVD			m_pFVF;
	PDEF			m_pEft;					// ID3DXEffect


	PDTX			m_pTexS;				// Scene Texture
	PDTX			m_pTexL;				// Luminescence Texture
	VtxDUV1			m_pVtx[4];				// Vertex Buffer

	IrenderTarget*	m_pTrndB[BLUR_MAX];		// Rendering Target Texture for Bluring
	IrenderTarget*	m_pTrndC[CROSS_MAX];	// Cross Texture
	IrenderTarget*	m_pTrndS;				// Cross Texture All

	float			m_fTxW;					// Blur Texture Width
	float			m_fTxH;					// Blur Texture Height
	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();


	void	SetSceneTexture(PDTX pTx);
	void	SetLuminescenceTexture(PDTX pTx);

	INT		Restore();
	void	Invalidate();
};

#endif
