// McMesh.cpp: implementation of the CMcMesh class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcMesh::CMcMesh()
{
	m_pMesh			= NULL;
	m_pMeshMtrl		= NULL;
	m_pMeshTexture	= NULL;
	m_dwNumMtrl		= 0L;  

	m_pFVF			= NULL;
}

CMcMesh::~CMcMesh()
{
	Destroy();
}


INT CMcMesh::Create(LPDIRECT3DDEVICE9 pDev, char* xFileName)
{
	HRESULT hr=-1;

	m_pDev = pDev;

	
	//��Ƽ���� ���۸� �������� ���� �ӽ� ����
	LPD3DXBUFFER pD3DXMtrlBuffer;
	
	//1. �޽��� ���� �ε��Ѵ�.
	
	if( FAILED( D3DXLoadMeshFromX( xFileName
		,	D3DXMESH_SYSTEMMEM
		,	m_pDev, NULL
		,	&pD3DXMtrlBuffer, NULL
		,	&m_dwNumMtrl, &m_pMesh ) ) )
	{
		return E_FAIL;
	}
	
	
	// 2. ��Ƽ����� �ؽ�ó�� �����Ѵ�.

	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	m_pMeshMtrl = new D3DMATERIAL9[m_dwNumMtrl];
	m_pMeshTexture  = new LPDIRECT3DTEXTURE9[m_dwNumMtrl];
	
	for( DWORD i=0; i<m_dwNumMtrl; i++ )
	{
		// ��Ƽ���� ����
		m_pMeshMtrl[i] = d3dxMaterials[i].MatD3D;
		
		// ��Ƽ������ Ambient ����
		m_pMeshMtrl[i].Ambient = m_pMeshMtrl[i].Diffuse;
		
		m_pMeshTexture[i] = NULL;

		if( d3dxMaterials[i].pTextureFilename != NULL &&  lstrlen(d3dxMaterials[i].pTextureFilename) > 0 )
		{
			
			// �ؽ�ó�� �����Ѵ�.
			TCHAR	sFile[512];

			sprintf(sFile, "xFile/%s", d3dxMaterials[i].pTextureFilename);
			
			//�ؽ�ó ����
			hr = D3DXCreateTextureFromFileEx(m_pDev
							, sFile
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0
							, D3DFMT_UNKNOWN
							, D3DPOOL_MANAGED
							, D3DX_DEFAULT
							, D3DX_DEFAULT
							, 0x00FFFFFF
							, NULL
							, NULL
							, &m_pMeshTexture[i]);
			
			if( FAILED( hr ) )
			{
				MessageBox( GetActiveWindow(), "Could not find texture map", "Meshes.exe", MB_OK);
			}

		}
	}
	
	// �ӽ� ���۸� �����Ѵ�.
	pD3DXMtrlBuffer->Release();

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(m_pMesh->GetFVF(), vertex_decl);


	LPDIRECT3DVERTEXDECLARATION9 pFVF;
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &pFVF)))
		return -1;

	m_pFVF = pFVF;


	return 0;
}

void CMcMesh::Destroy()
{
	if( m_pMeshMtrl != NULL ) 
		delete[] m_pMeshMtrl;
	
	if( m_pMeshTexture )
	{
		for( DWORD i = 0; i < m_dwNumMtrl; i++ )
		{
			if( m_pMeshTexture[i] )
				m_pMeshTexture[i]->Release();
		}
		
		delete[] m_pMeshTexture;
		m_pMeshTexture = NULL;
	}
	
	if(m_pMesh)
	{
		m_pMesh->Release();
		m_pMesh = NULL;
	}

	if(m_pFVF)
	{
		((LPDIRECT3DVERTEXDECLARATION9)m_pFVF)->Release();
		m_pFVF = NULL;
	}
}

INT CMcMesh::FrameMove()
{
	return 0;
}

void CMcMesh::Render(INT bTex, void* pEft)
{
	// �ؽ�ó U, V, W�� ��巹�� ��带 Wrap���� �����Ѵ�.
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

	// �ؽ�ó�� ���͸��� Linear�� �����Ѵ�.
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_ALPHAREF,        156 );
	m_pDev->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATER );


	if(!bTex)
	{
		m_pDev->SetRenderState( D3DRS_TEXTUREFACTOR, 0xFF000000);
		m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TFACTOR);
		m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	}

	LPD3DXEFFECT	pd3Eft = (LPD3DXEFFECT)pEft;

	for( DWORD i=0; i<m_dwNumMtrl; i++ )
	{
		// Set the material and texture for this subset
		m_pDev->SetMaterial( &m_pMeshMtrl[i] );
		m_pDev->SetTexture( 0, m_pMeshTexture[i] );

		if(pd3Eft)
			pd3Eft->CommitChanges();

		// Draw the mesh subset
		m_pMesh->DrawSubset( i );
	}


	if(!bTex)
	{
		m_pDev->SetRenderState( D3DRS_TEXTUREFACTOR, 0xFFFFFFFF);
		m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
		m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	}

	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetTexture( 0, NULL);
}


void* CMcMesh::GetVertexDeclaration()
{
	return m_pFVF;
}
