// McGrid.h: interface for the CMcGrid class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MCGRID_H__62DD9A49_3C6B_4EF9_9030_C22434EFA755__INCLUDED_)
#define AFX_MCGRID_H__62DD9A49_3C6B_4EF9_9030_C22434EFA755__INCLUDED_


class CMcGrid  
{
public:
	struct VtxD
	{
		D3DXVECTOR3	p;		// ��ġ(X,Y,Z)
		DWORD		d;		// ����

		VtxD(){};
		VtxD(FLOAT X, FLOAT Y, FLOAT Z, DWORD D=0xFFFFFFFF) : p(X,Y,Z), d(D){}

		enum { FVF=(D3DFVF_XYZ | D3DFVF_DIFFUSE),};
	};

protected:
	LPDIRECT3DDEVICE9		m_pDev;
	INT						m_nVtx;					// ���� ��
    LPDIRECT3DVERTEXBUFFER9 m_pVB;                  // ���ؽ� ����

	
public:
	CMcGrid();
	virtual ~CMcGrid();

	INT		Create(LPDIRECT3DDEVICE9 pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
