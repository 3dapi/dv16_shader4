// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;

	m_pEft		= NULL;
	m_pFVFD		= NULL;
	m_pFVFN		= NULL;

	m_pMesh		= NULL;
	
	
	m_pTxShd	= NULL;

	m_pTrndInk	= NULL;
	m_pTrndTmp	= NULL;



	// ��������
	m_pVtx[0] = VtxDUV1( -0.99F, 0.99F, 0,   0, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1(  0.99F, 0.99F, 0,   1, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1(  0.99F,-0.99F, 0,   1, 1, D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1( -0.99F,-0.99F, 0,   0, 1, D3DXCOLOR(1,1,1,1));

	m_pVtx[0] = VtxDUV1( -1.F, 1.F, 0,   0, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1(  1.F, 1.F, 0,   1, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1(  1.F,-1.F, 0,   1, 1, D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1( -1.F,-1.F, 0,   0, 1, D3DXCOLOR(1,1,1,1));
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = pDev;

	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	LPD3DXBUFFER	pErr	= NULL;


	hr = D3DXCreateEffectFromFile(
							m_pDev
							,	"data/HLSL.fx"
							,	NULL
							,	NULL
							,	dwFlags
							,	NULL
							,	&m_pEft
							,	&pErr);


	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}


	D3DVERTEXELEMENT9 vtx_dcl[MAX_FVF_DECL_SIZE]={0};
	DWORD dFVFN = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1);
	D3DXDeclaratorFromFVF(dFVFN, vtx_dcl);

	if(FAILED(m_pDev->CreateVertexDeclaration( vtx_dcl, &m_pFVFN )))
		return -1;


	memset(vtx_dcl, 0, sizeof(vtx_dcl));
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vtx_dcl);

	if(FAILED(m_pDev->CreateVertexDeclaration( vtx_dcl, &m_pFVFD )))
		return -1;



	D3DXCreateTextureFromFile( m_pDev, "data/shade.bmp", &m_pTxShd);

	
	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndInk, m_pDev)))
		return -1;

	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndTmp, m_pDev)))
		return -1;


	// ������
	LPD3DXMESH		pMshO = NULL;
	LPD3DXBUFFER	pAdjc = NULL;

    // Load the mesh
    hr = D3DXLoadMeshFromX( "Data/bigship1.x"
								, D3DXMESH_SYSTEMMEM
								, m_pDev
								, &pAdjc
								, NULL
								, NULL
								, NULL
								, &pMshO );

	if(FAILED(hr))
		return hr;


    // Optimize the mesh for performance
	hr = pMshO->OptimizeInplace(
                        D3DXMESHOPT_COMPACT | D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE
						, (DWORD*)pAdjc->GetBufferPointer()
						, NULL
						, NULL
						, NULL );

    if( FAILED(hr))
        return hr;


	pMshO->CloneMeshFVF(D3DXMESH_MANAGED, dFVFN, m_pDev, &m_pMesh );
	D3DXComputeNormals( m_pMesh, NULL );

	SAFE_RELEASE(	pMshO	);
	SAFE_RELEASE(	pAdjc	);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_RELEASE(	m_pFVFN		);
	SAFE_RELEASE(	m_pFVFD		);

	SAFE_RELEASE(	m_pTxShd	);
	SAFE_DELETE(	m_pTrndTmp	);
	SAFE_DELETE(	m_pTrndInk	);

	SAFE_RELEASE(	m_pMesh		);
}


INT CShaderEx::FrameMove()
{
	PDTX pTx = NULL;
	HRESULT hr=0;


	for(int i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	}


	// ��ļ���
	D3DXMATRIX	mtWVP;			// World * View * Projection Matrix
	D3DXMATRIX	mtViw;			// View Matrix
	D3DXMATRIX	mtPrj;			// Projection Matrix
	D3DXMATRIX	mtSRT;			// Scaling * Rotation * Translation

	D3DXMATRIX	mtRot;
	D3DXMATRIX	mtScl;
	D3DXMATRIX	mtTrs;

	D3DXMATRIX	mtVwI;
	D3DXVECTOR4	vcLgt;
	D3DXVECTOR4	vcEye;


	FLOAT	fTime = g_pApp->GetTime()*0.3f;

//	fTime = 0.3f;

	m_pDev->GetTransform( D3DTS_VIEW,  &mtViw );
	m_pDev->GetTransform( D3DTS_PROJECTION,  &mtPrj );

	D3DXMatrixInverse(&mtVwI, NULL, &mtViw);			// ����Ŀ��� ī�޶��� ��ġ�� ��´�.

	vcLgt	= D3DXVECTOR4( -1.f, -1.f,	1.f, 0);					// ������ ����
	vcEye	= D3DXVECTOR4(mtViw._41, mtViw._42, mtViw._43, 0);

	D3DXVec4Normalize( &vcLgt, &vcLgt );

	D3DXMatrixRotationY(  &mtRot, fTime );						// �������(ȸ��)
	D3DXMatrixScaling(    &mtScl, 10.f, 10.f, 10.f );			// ũ�����
	D3DXMatrixTranslation(&mtTrs, 0.f, 20.f ,-2.f );			// �̵� ���


	mtWVP = mtScl * mtRot * mtTrs * mtViw * mtPrj;				// ������ ���� ���
	mtSRT = mtScl * mtRot * mtTrs;								// ������ ������, ȸ��, �̵�




	////////////////////////////////////////////////////////////////////////////
	// Ink Process

	// Render to Ink Texture
	m_pTrndInk->BeginScene((0x1L|0x2L), 0xFFffffff);

		hr = m_pDev->SetVertexDeclaration( m_pFVFN );			// ���� ����
		hr = m_pDev->SetTexture(0, m_pTxShd);					// ���� ����

		hr = m_pEft->SetMatrix( "m_mtWVP", &mtWVP);				// ����*��*�������� ��ȯ ���
		hr = m_pEft->SetMatrix( "mtSRT"  , &mtSRT);				// Scaling * Rotation * Translation
		hr = m_pEft->SetMatrix( "m_mtRot", &mtRot);				// ȸ�� ��ȯ ���
		hr = m_pEft->SetVector( "m_vcLgt", &vcLgt );			// ������ ����
		hr = m_pEft->SetVector( "m_vcEye", &vcEye);				// Camera Eye

		hr = m_pEft->SetTechnique( "TechInk");

		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(2);

			hr = m_pMesh->DrawSubset( 0 );

		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndInk->EndScene();


	// Blurring X
	
	pTx = (PDTX)m_pTrndInk->GetTexture();
	
	m_pTrndTmp->BeginScene();

		hr = m_pDev->SetVertexDeclaration( m_pFVFD );
		hr = m_pEft->SetTechnique( "TechBlur");
		hr = m_pDev->SetTexture( 0, pTx);

		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(0);

			hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndTmp->EndScene();



	// Blurring Y

	pTx = (PDTX)m_pTrndTmp->GetTexture();

	m_pTrndInk->BeginScene();
		hr = m_pDev->SetVertexDeclaration( m_pFVFD );
		hr = m_pEft->SetTechnique( "TechBlur");
		hr = m_pDev->SetTexture( 0, pTx);

		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(1);

			hr = m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndInk->EndScene();

	//
	////////////////////////////////////////////////////////////////////////////


	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);

	return 0;
}


INT CShaderEx::Restore()
{
	if(m_pEft)
		m_pEft->OnResetDevice();

	m_pTrndInk->OnResetDevice();
	m_pTrndTmp->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	if(m_pEft)
		m_pEft->OnLostDevice();


	m_pTrndInk->OnLostDevice();
	m_pTrndTmp->OnLostDevice();
}


void CShaderEx::Render()
{
	INT		i=0;
	HRESULT hr=0;
	D3DXMATRIX mtI(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);

	for(i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}



	PDTX pTx0 = (PDTX)m_pTrndInk->GetTexture();

	m_pDev->SetTexture(0, pTx0);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));



	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);


	for(i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}
}



