// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_


typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXEFFECT					PDEF;


class CShaderEx
{
public:
	struct VtxDUV1
	{
		D3DXVECTOR3	p;
		DWORD		d;
		FLOAT		u, v;

		VtxDUV1()						: p(0,0,0),u(0),v(0),d(0xFFFFFFFF){}
		VtxDUV1( FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT U, FLOAT V, DWORD D=0XFFFFFFFF
				)	: p(X,Y,Z), u(U),v(V), d(D){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)	};
	};


public:
	PDEV		m_pDev;				// Device

	PDEF		m_pEft;				// Vertex Shader
	PDVD		m_pFVFD;			// Declarator Normal
	PDVD		m_pFVFN;			// Declarator Diffuse

	LPD3DXMESH	m_pMesh;			// ������ �޽�

	
	VtxDUV1		m_pVtx[4];


	PDTX		m_pTxShd;			// Shading ��
	IrenderTarget*	m_pTrndInk;		// Ink Effect
	IrenderTarget*	m_pTrndTmp;		// Blurring for Tmp


public:
	CShaderEx();
	virtual ~CShaderEx();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

