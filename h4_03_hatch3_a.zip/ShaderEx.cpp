// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;
	
	m_pTex0	= NULL;
	m_pTex1	= NULL;
	m_pTex2	= NULL;
	m_pTex3	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	
	m_pDev	= pDev;
	
	
	m_pVtx[0] = VtxUV1( -.9f,  .9f,	 0.f, 0.f );
	m_pVtx[1] = VtxUV1(  .9f,  .9f,	 1.f, 0.f );
	m_pVtx[2] = VtxUV1(  .9f, -.9f,	 1.f, 1.f );
	m_pVtx[3] = VtxUV1( -.9f, -.9f,	 0.f, 1.f );

	m_pVtx[0] = VtxUV1( -1.f,  1.f,	 0.f, 0.f );
	m_pVtx[1] = VtxUV1(  1.f,  1.f,	 1.f, 0.f );
	m_pVtx[2] = VtxUV1(  1.f, -1.f,	 1.f, 1.f );
	m_pVtx[3] = VtxUV1( -1.f, -1.f,	 0.f, 1.f );
	
	
	DWORD dwFlags = 0;
#if defined( _DEBUG ) || defined( DEBUG )
	dwFlags |= D3DXSHADER_DEBUG;
#endif
	
	LPD3DXBUFFER pErr = NULL;
	
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}
	
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile(m_pDev, "Texture/Lvl1.bmp", &m_pTex1);
	D3DXCreateTextureFromFile(m_pDev, "Texture/Lvl2.bmp", &m_pTex2);
	D3DXCreateTextureFromFile(m_pDev, "Texture/Lvl3.bmp", &m_pTex3);



	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);

	SAFE_RELEASE(	m_pTex1	);
	SAFE_RELEASE(	m_pTex2	);
	SAFE_RELEASE(	m_pTex3	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
//	FOR Debug
	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);
//	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
//	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
//	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);


	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);


	for(int i=0; i<4; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}


	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pEft->SetTechnique("Tech");


	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->SetTexture(0, m_pTex0);
		m_pDev->SetTexture(1, m_pTex1);
		m_pDev->SetTexture(2, m_pTex2);
		m_pDev->SetTexture(3, m_pTex3);
		m_pDev->SetFVF(VtxUV1::FVF);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
	m_pDev->SetTexture(2, NULL);
	m_pDev->SetTexture(3, NULL);

	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
}



INT CShaderEx::Restore()
{

	m_pEft->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTex0 = pTx;
}

	
