// Implementation of the CMcParticle class.
//
////////////////////////////////////////////////////////////////////////////////
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

#include <Windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "McParticle.h"


inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }



CMcParticle::CMcParticle()
{
	m_pDev		= NULL;

	m_PrtN		= 0;
	m_PrtD		= NULL;

	m_pVB		= NULL;
	m_pTx		= NULL;


	m_fTimeEps	= 10.f;
}

CMcParticle::~CMcParticle()
{
	Destroy();
}


INT CMcParticle::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	m_PrtN	= 500;
	m_PrtD	= new CMcParticle::Tpart[m_PrtN];
	

	// ������ � ��¿� ����
	m_pDev->CreateVertexBuffer(m_PrtN* sizeof(CMcParticle::VtxDRHW)
							, D3DUSAGE_POINTS
							, CMcParticle::VtxDRHW::FVF
							, D3DPOOL_MANAGED
							, &m_pVB, 0);
	

	D3DXCreateTextureFromFile(m_pDev, "Texture/Noise.tga", &m_pTx);


	for(int i=0; i<m_PrtN; ++i)
	{
		SetPart(i);
	}


	return 0;
}


void CMcParticle::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
	SAFE_RELEASE(	m_pTx	);
	
	SAFE_DELETE_ARRAY(	m_PrtD	);
}

INT CMcParticle::FrameMove()
{
	int		i;

	FLOAT	ftime = m_fTimeEps;


	for(i=0; i<m_PrtN; ++i)
	{
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		// 3. ���� ��ġ ����
		pPrt->m_CrnP += pPrt->m_CrnV * ftime;


		float	f = (100 - rand()%201) * 0.01f;

		pPrt->m_CrnP.x +=f;

		// 4. ��谪 ����
		pPrt->m_dCol += pPrt->m_vCol*ftime;

		if(pPrt->m_dCol.r < 0)	pPrt->m_dCol.r = 0;
		if(pPrt->m_dCol.g < 0)	pPrt->m_dCol.g = 0;
		if(pPrt->m_dCol.b < 0)	pPrt->m_dCol.b = 0;

		if(pPrt->m_CrnP.y<0.f|| pPrt->m_dCol.a < 0)
		{
			SetPart(i);
		}
	}



	// ������ ��� Vertex Buffer�� ����
	CMcParticle::VtxDRHW*	pVtx;
	m_pVB->Lock(0,0,(void**)&pVtx, 0);

	for(i=0; i<m_PrtN; ++i)
	{	
		CMcParticle::Tpart* pPrt = &m_PrtD[i];

		pVtx[i].p.x = pPrt->m_CrnP.x;
		pVtx[i].p.y = pPrt->m_CrnP.y;
		pVtx[i].p.z = 0;
		pVtx[i].p.w = 1;
		pVtx[i].d = pPrt->m_dCol;
	}

	m_pVB->Unlock();

	return 0;
}

void CMcParticle::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetRenderState(D3DRS_POINTSPRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_POINTSCALEENABLE, TRUE); 
	m_pDev->SetRenderState(D3DRS_POINTSIZE, FtoDW(120.f));
	m_pDev->SetRenderState(D3DRS_POINTSIZE_MIN, FtoDW(1.0f));


	m_pDev->SetRenderState(D3DRS_POINTSCALE_A, FtoDW(1.0f));
	m_pDev->SetRenderState(D3DRS_POINTSCALE_B, FtoDW(2.0f));
	m_pDev->SetRenderState(D3DRS_POINTSCALE_C, FtoDW(3.0f));



	m_pDev->SetFVF(CMcParticle::VtxDRHW::FVF);	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(CMcParticle::VtxDRHW));

	m_pDev->DrawPrimitive(D3DPT_POINTLIST, 0, m_PrtN);

	m_pDev->SetTexture(0, NULL);
}





void CMcParticle::SetPart(int nIdx)
{
	CMcParticle::Tpart* pPrt = &m_PrtD[nIdx];

	FLOAT	fSpdR;		// �ӵ� ũ��

	fSpdR = 100.f + rand()%301;
	fSpdR *=1.25f;

	// �ʱ� �ӵ�
	pPrt->m_IntV.x = 0;
	pPrt->m_IntV.y = -fSpdR;

	// �ʱ� ��ġ		
	pPrt->m_IntP.x = FLOAT(rand()%800);
	pPrt->m_IntP.y = 600.f;


	// �ʱ� ��ġ, �ӵ�, ���ӵ��� ������ ������ �ʱ� ������ ����
	pPrt->m_CrnP = pPrt->m_IntP;
	pPrt->m_CrnV = pPrt->m_IntV;

	float r = 0;


	r = (rand()%156 + 100)*(-0.005F);
	pPrt->m_dCol	= D3DXCOLOR(1.f, 0.5f, 0, 1);
	pPrt->m_vCol	= pPrt->m_dCol*r;

}



void CMcParticle::SetTimeEps(FLOAT fTime)
{
	m_fTimeEps = fTime;
}