// Interface for the CWaterBubble class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCPARTICLE_H_
#define _MCPARTICLE_H_


class CWaterBubble
{
public:
	struct VtxDRHW
	{
		D3DXVECTOR4	p;
		FLOAT		s;
		
		VtxDRHW() : p(0,0,0, 1), s(50.0F){}
		VtxDRHW(FLOAT X,FLOAT Y, FLOAT S): p(X,Y, 0.0F, 1.0F), s(S){}
		
		enum { FVF =(D3DFVF_XYZRHW|D3DFVF_PSIZE) };
	};
	
	struct Tpart
	{
		FLOAT			m_size;		// point size

		// ������ � ���
		D3DXVECTOR2		m_IntP;		// �ʱ� ��ġ
		D3DXVECTOR2		m_IntV;		// �ʱ� �ӵ�

		D3DXVECTOR2		m_CrnP;		// ���� ��ġ
		D3DXVECTOR2		m_CrnV;		// ���� �ӵ�
		
		D3DXCOLOR		m_vCol;
	};
	
protected:
	LPDIRECT3DDEVICE9	m_pDev;
	
	INT				m_PrtN;			// ������ ��
	Tpart*			m_PrtD;			// Particle Data
	
	// ȭ�� ��¿�
	LPDIRECT3DVERTEXBUFFER9	m_pVB;
	LPDIRECT3DTEXTURE9		m_pTx;

	FLOAT			m_fTimeEps;
	
	
public:
	CWaterBubble();
	virtual ~CWaterBubble();
	
	INT		Create(LPDIRECT3DDEVICE9);
	void	Destroy();
	
	INT		FrameMove();
	void	Render();


	void	SetTimeEps(FLOAT fTime);
	
protected:
	void	SetPart(int nIdx);
};

#endif

