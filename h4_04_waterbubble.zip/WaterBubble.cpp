// Implementation of the CWaterBubble class.
//
////////////////////////////////////////////////////////////////////////////////
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

#include <Windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "WaterBubble.h"


inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }



CWaterBubble::CWaterBubble()
{
	m_pDev		= NULL;

	m_PrtN		= 0;
	m_PrtD		= NULL;

	m_pVB		= NULL;
	m_pTx		= NULL;


	m_fTimeEps	= 10.f;
}

CWaterBubble::~CWaterBubble()
{
	Destroy();
}


INT CWaterBubble::Create(LPDIRECT3DDEVICE9 pDev)
{
	m_pDev = pDev;

	m_PrtN	= 40;
	m_PrtD	= new CWaterBubble::Tpart[m_PrtN];
	

	// ������ � ��¿� ����
	m_pDev->CreateVertexBuffer(m_PrtN* sizeof(CWaterBubble::VtxDRHW)
							, D3DUSAGE_POINTS
							, CWaterBubble::VtxDRHW::FVF
							, D3DPOOL_MANAGED
							, &m_pVB, 0);
	

	D3DXCreateTextureFromFile(m_pDev, "Texture/normal.png", &m_pTx);


	for(int i=0; i<m_PrtN; ++i)
	{
		CWaterBubble::Tpart* pPrt = &m_PrtD[i];

		pPrt->m_size   = 10.0F + 5.0F * (rand()%20);

		FLOAT	fSpdR = 20.f + rand()%51;
		fSpdR *=1.25f;

		// �ʱ� �ӵ�
		pPrt->m_IntV.x = 0;
		pPrt->m_IntV.y = -fSpdR;

		// �ʱ� ��ġ		
		pPrt->m_IntP.x = FLOAT(rand()%800);
		pPrt->m_IntP.y = 600.0f + pPrt->m_size;

		// �ʱ� ��ġ, �ӵ�, ���ӵ��� ������ ������ �ʱ� ������ ����
		pPrt->m_CrnP = pPrt->m_IntP;
		pPrt->m_CrnV = pPrt->m_IntV;
	}


	return 0;
}


void CWaterBubble::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
	SAFE_RELEASE(	m_pTx	);
	
	SAFE_DELETE_ARRAY(	m_PrtD	);
}

INT CWaterBubble::FrameMove()
{
	int		i;

	FLOAT	ftime = m_fTimeEps;


	for(i=0; i<m_PrtN; ++i)
	{
		CWaterBubble::Tpart* pPrt = &m_PrtD[i];

		// 3. ���� ��ġ ����
		pPrt->m_CrnP += pPrt->m_CrnV * ftime;


		// 4. ��谪 ����
		if(pPrt->m_CrnP.y<-pPrt->m_size)
		{
			SetPart(i);
		}
	}



	// ������ ��� Vertex Buffer�� ����
	CWaterBubble::VtxDRHW*	pVtx;
	m_pVB->Lock(0,0,(void**)&pVtx, 0);

	for(i=0; i<m_PrtN; ++i)
	{	
		CWaterBubble::Tpart* pPrt = &m_PrtD[i];

		pVtx[i].p.x = pPrt->m_CrnP.x;
		pVtx[i].p.y = pPrt->m_CrnP.y;
		pVtx[i].p.z = 0.0F;
		pVtx[i].p.w = 1.0F;
		pVtx[i].s = pPrt->m_size;
	}

	m_pVB->Unlock();

	return 0;
}

void CWaterBubble::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);


	m_pDev->SetRenderState(D3DRS_POINTSPRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_POINTSCALEENABLE, TRUE); 
	m_pDev->SetRenderState(D3DRS_POINTSIZE, FtoDW(120.f));
	m_pDev->SetRenderState(D3DRS_POINTSIZE_MIN, FtoDW(1.0f));


	m_pDev->SetRenderState(D3DRS_POINTSCALE_A, FtoDW(1.0f));
	m_pDev->SetRenderState(D3DRS_POINTSCALE_B, FtoDW(2.0f));
	m_pDev->SetRenderState(D3DRS_POINTSCALE_C, FtoDW(3.0f));


	m_pDev->SetFVF(CWaterBubble::VtxDRHW::FVF);	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetStreamSource(0, m_pVB, 0, sizeof(CWaterBubble::VtxDRHW));

	m_pDev->DrawPrimitive(D3DPT_POINTLIST, 0, m_PrtN);

	m_pDev->SetTexture(0, NULL);
}





void CWaterBubble::SetPart(int nIdx)
{
	CWaterBubble::Tpart* pPrt = &m_PrtD[nIdx];

	pPrt->m_size   = 10.0F + 5.0F * (rand()%20);

	FLOAT	fSpdR = 20.f + rand()%51;
	fSpdR *=1.25f;

	// �ʱ� �ӵ�
	pPrt->m_IntV.x = 0;
	pPrt->m_IntV.y = -fSpdR;

	// �ʱ� ��ġ		
	pPrt->m_IntP.x = FLOAT(rand()%800);
	pPrt->m_IntP.y = 600.0f + pPrt->m_size;

	// �ʱ� ��ġ, �ӵ�, ���ӵ��� ������ ������ �ʱ� ������ ����
	pPrt->m_CrnP = pPrt->m_IntP;
	pPrt->m_CrnV = pPrt->m_IntV;
}



void CWaterBubble::SetTimeEps(FLOAT fTime)
{
	m_fTimeEps = fTime;
}