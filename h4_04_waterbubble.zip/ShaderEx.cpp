// Implementation of the CWaterEffect class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CWaterEffect::CWaterEffect()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	
	m_pTex	= NULL;

	m_pDst	= NULL;
}


CWaterEffect::~CWaterEffect()
{
	Destroy();
}


INT CWaterEffect::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0, 0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1, 0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1, 1, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0, 1, D3DXCOLOR(0,0,1,1));


	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	LPD3DXBUFFER	pErr	= NULL;
	
	hr = D3DXCreateEffectFromFile(	m_pDev
									,	"data/Shader.fx"
									,	NULL
									,	NULL
									,	dwFlags
									,	0
									,	&m_pEft
									,	&pErr);
	
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}

	D3DXCreateTextureFromFile(m_pDev, "Texture/underwater.png", &m_pTex);


	SAFE_NEWCREATE1(m_pDst, CWaterDistort, m_pDev);

	return 0;
}

void CWaterEffect::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pTex	);

	SAFE_DELETE(	m_pDst	);
}


INT CWaterEffect::Restore()
{
	m_pDst->Restore();
	return m_pEft->OnResetDevice();
}

void CWaterEffect::Invalidate()
{
	m_pDst->Invalidate();
	m_pEft->OnLostDevice();
}


INT CWaterEffect::FrameMove()
{
	m_pDst->FrameMove();
	return 0;
}


void CWaterEffect::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	m_pDev->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);


	m_pDev->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, 0);


	FLOAT	hHeatHaze = .1f;
	PDTX	pTex0 = m_pTex;
	PDTX	pTex1 = m_pDst->GetTexture();


	m_pEft->SetTechnique("Tech");

	m_pEft->SetFloat("g_HeatHaze", hHeatHaze);

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->SetTexture(0, pTex0);
		m_pDev->SetTexture(1, pTex1);
		m_pDev->SetFVF(VtxDUV1::FVF);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);

	
	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);

	m_pDst->Render();
}


