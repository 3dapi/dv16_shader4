// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_

typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef LPDIRECT3DVERTEXSHADER9				PDVS;
typedef LPDIRECT3DPIXELSHADER9				PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;

typedef LPDIRECT3DTEXTURE9					PDTX;
typedef	ID3DXEffect*						PDEF;



struct VtxDUV1
{
	VEC3	p;
	DWORD	d;
	FLOAT	u,v;
	
	VtxDUV1()	: p(0,0,0),d(0xFFFFFFFF),u(0),v(0){}
	VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT U,FLOAT V, DWORD D=0XFFFFFFFF):p(X,Y,Z),u(U),v(V),d(D){}

	enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
};


class CMain : public CD3DApplication
{
protected:
	CMcInput*		m_pInput;
	CMcCam*			m_pCam;
	CMcGrid*		m_pGrid;
	ID3DXFont*      m_pD3DXFont;            // D3DX font

	CMcField*		m_pField;

	INT				m_TreeNum;
	CMcMesh*		m_TreeMsh;
	D3DXMATRIX*		m_TreeMat;
	CMcMesh*		m_SkyBox;

	


public:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();
			void	RenderScene();

    HRESULT RenderText();

public:
	CMain();
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
};


extern CMain* g_pApp;

#endif



