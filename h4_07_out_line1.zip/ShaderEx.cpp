// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;
	
	m_pTex		= NULL;

	m_pTrndX	= NULL;
	m_pTrndY	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	
	m_pDev	= pDev;
	
	
	m_pVtx[0] = VtxDUV1( -.9f,  .9f, 0.f,	 0.f, 0.f );
	m_pVtx[1] = VtxDUV1(  .9f,  .9f, 0.f,	 1.f, 0.f );
	m_pVtx[2] = VtxDUV1(  .9f, -.9f, 0.f,	 1.f, 1.f );
	m_pVtx[3] = VtxDUV1( -.9f, -.9f, 0.f,	 0.f, 1.f );

	m_pVtx[0] = VtxDUV1( -1.f,  1.f, 0.f,	 0.f, 0.f );
	m_pVtx[1] = VtxDUV1(  1.f,  1.f, 0.f,	 1.f, 0.f );
	m_pVtx[2] = VtxDUV1(  1.f, -1.f, 0.f,	 1.f, 1.f );
	m_pVtx[3] = VtxDUV1( -1.f, -1.f, 0.f,	 0.f, 1.f );
	
	
	DWORD dwFlags = 0;
#if defined( _DEBUG ) || defined( DEBUG )
	dwFlags |= D3DXSHADER_DEBUG;
#endif
	
	LPD3DXBUFFER pErr = NULL;
	
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/hlsl.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}
	
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTex);


	m_TexW = 240;
	m_TexH = 180;

	m_TexW = 800;
	m_TexH = 600;


	// ���� Ÿ�Ͽ� �ؽ�ó ����
	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndX, m_pDev, m_TexW,m_TexH)))
		return -1;

	// ���� Ÿ�Ͽ� �ؽ�ó ����
	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrndY, m_pDev, m_TexW,m_TexH)))
		return -1;
	

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_RELEASE(	m_pFVF		);

	SAFE_DELETE(	m_pTrndX	);
	SAFE_DELETE(	m_pTrndY	);

	SAFE_RELEASE(	m_pTex		);
}


INT CShaderEx::FrameMove()
{
	HRESULT hr =0;
	PDTX	pTx =NULL;
	int		i=0;


	for(i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	}


	// �� ��� �ؽ�ó

	static int passIdx = 2;

	if(::GetAsyncKeyState('S')&0x8000)
		passIdx = 0;

	else if(::GetAsyncKeyState('L')&0x8000)
		passIdx = 1;
	else
		passIdx = 2;


	pTx= m_pTex;

	m_pTrndY ->BeginScene();
		hr = m_pDev->Clear( 0L, NULL, 0x1L| 0x2L, 0x00006699, 1.0f, 0L );
	
		m_pDev->SetVertexDeclaration(m_pFVF);
	
		hr = m_pEft->SetTechnique("TechOutline"); 
		hr = m_pEft->SetTexture( "m_pTxDif", pTx);
		hr = m_pEft->SetFloat( "m_TexW", m_TexW);
		hr = m_pEft->SetFloat( "m_TexH", m_TexH);

		hr = m_pEft->Begin(NULL, 0);
		hr = m_pEft->BeginPass(passIdx);

		 	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
	
		m_pEft->EndPass();
		m_pEft->End();

	m_pTrndY->EndScene();


	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	return 0;
}


void CShaderEx::Render()
{
	int i=0;
	HRESULT hr=0;


	D3DXMATRIX mtI;		
	D3DXMatrixIdentity(&mtI);
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);


	PDTX	pTex1 = (PDTX)m_pTrndY->GetTexture();


	m_pDev->SetTexture(0, pTex1);

	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));
}



INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();
	m_pTrndX->OnResetDevice();
	m_pTrndY->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
	m_pTrndX->OnLostDevice();
	m_pTrndY->OnLostDevice();
}


