#ifndef _MAIN_H_
#define _MAIN_H_



class CMain : public CD3DApplication
{
public:
	ID3DXFont*	m_pD3DXFont;														// D3DX font
	TCHAR		m_sMsg[512];

	CMcInput*	m_pInput;
	CMcCam*		m_pCam;
	CMcGrid*	m_pGrid;

	PDEF			m_pEft		;		// ID3DXEffect ��ü


	CShaderEx*		m_pShader	;


	IrenderTarget*	m_pTrndS	;		// for scene
	IrenderTarget*	m_pTrndD	;		// for distortion

	CMcField*		m_pField	;
	INT				m_TreeNum	;
	CMcMesh*		m_TreeMsh	;
	D3DXMATRIX*		m_TreeMat	;
	CMcMesh*		m_SkyBox	;

	CMcParticle*	m_pPrt		;


public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT Render();
	virtual HRESULT FrameMove();

	void	RenderScene(BOOL bDistort=FALSE);
	
	
public:
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	CMain();	
};


extern CMain*	g_pApp;


#endif