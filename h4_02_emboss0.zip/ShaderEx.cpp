// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	
	m_pTex0	= NULL;
	m_pTex1	= NULL;

	m_pTexP	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1, 1, D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0, 1, D3DXCOLOR(1,1,1,1));


	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	LPD3DXBUFFER	pErr	= NULL;
	
	hr = D3DXCreateEffectFromFile(	m_pDev
									,	"data/Shader.fx"
									,	NULL
									,	NULL
									,	dwFlags
									,	0
									,	&m_pEft
									,	&pErr);
	
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}


	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTex0);

	D3DXCreateTextureFromFileEx(m_pDev
								, "Texture/pattern_circle.png"
								, D3DX_DEFAULT, D3DX_DEFAULT
								, D3DX_DEFAULT
								, 0, D3DFMT_UNKNOWN
								, D3DPOOL_MANAGED
								, D3DX_DEFAULT
								, D3DX_DEFAULT
								, 0x00FFFFFF
								, NULL
								, NULL
								, &m_pTex1);

	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTexP, m_pDev)))
		return -1;


	

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pTex0	);
	SAFE_RELEASE(	m_pTex1	);

	SAFE_DELETE(	m_pTexP	);
}


INT CShaderEx::Restore()
{
	m_pTexP->OnResetDevice();




	m_pTexP->BeginScene();

	m_pDev->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0XFF8080FF, 1, 0);


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	//	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	//	m_pDev->SetRenderState(D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
	//	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0X10);

	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1);


	m_fW = 12;

	struct T
	{
		D3DXVECTOR4	p;
		D3DXVECTOR2	t;
	};

	T	pVtx[4];

	pVtx[0].p = D3DXVECTOR4(0,0,0,1);
	pVtx[1].p = D3DXVECTOR4(0,0,0,1);
	pVtx[2].p = D3DXVECTOR4(0,0,0,1);
	pVtx[3].p = D3DXVECTOR4(0,0,0,1);

	pVtx[0].t = D3DXVECTOR2(0,0);
	pVtx[1].t = D3DXVECTOR2(1,0);
	pVtx[2].t = D3DXVECTOR2(1,1);
	pVtx[3].t = D3DXVECTOR2(0,1);


	INT i, j;

	for(j=0; j<31; ++j)
	{
		for(i=0; i<41; ++i)
		{
			pVtx[0].p.x = i*10 - m_fW;
			pVtx[0].p.y = j*10 - m_fW;

			pVtx[1].p.x = pVtx[0].p.x + m_fW;
			pVtx[1].p.y = pVtx[0].p.y + 0 ;

			pVtx[2].p.x = pVtx[0].p.x + m_fW;
			pVtx[2].p.y = pVtx[0].p.y + m_fW;

			pVtx[3].p.x = pVtx[0].p.x + 0 ;
			pVtx[3].p.y = pVtx[0].p.y + m_fW;

			
			pVtx[0].p *= 2;
			pVtx[1].p *= 2;
			pVtx[2].p *= 2;
			pVtx[3].p *= 2;


			m_pDev->SetTexture(0, m_pTex1);

			m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, pVtx, sizeof(T));
		}
	}


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);

	m_pTexP->EndScene();
	

	return m_pEft->OnResetDevice();
}

void CShaderEx::Invalidate()
{
	m_pTexP->OnLostDevice();

	m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
//	FOR Debug


#if	0
	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);


	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	LPDIRECT3DTEXTURE9 pTex = (LPDIRECT3DTEXTURE9)m_pTexP->GetTexture();
	m_pDev->SetTexture(0, pTex);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

#else
	
	PDTX	pTxPt = (PDTX)m_pTexP->GetTexture();

	FLOAT	fPrtb = 200;
	fPrtb = 80;

	fPrtb /= m_fW;

	m_pEft->SetTechnique("Tech");

	m_pEft->SetTexture("m_TxDif", m_pTex0);
	m_pEft->SetTexture("m_TxPtn", pTxPt);

	m_pEft->SetFloat("m_fWidth", fPrtb);

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->SetFVF(VtxDUV1::FVF);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();


#endif
	m_pDev->SetTexture(0, NULL);

	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
}
