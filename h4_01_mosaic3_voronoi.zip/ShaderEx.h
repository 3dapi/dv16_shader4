// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;

typedef LPDIRECT3DDEVICE9					PDEV;


typedef	LPD3DXEFFECT						PDEF;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;

typedef LPDIRECT3DTEXTURE9					PDTX;




class CShaderEx
{
public:
	PDEV		m_pDev;				// Device

	PDEF		m_pEft;				// Effect
	PDTX		m_pTex;				// Texture - diffuse

	LPD3DXMESH	m_pCon;

	INT			m_nCon;
	VEC4*		m_pPos;

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif
