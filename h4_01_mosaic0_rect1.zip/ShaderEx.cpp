// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	
	m_pFVF	= NULL;
	m_pEft	= NULL;
	
	m_pTex	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0, 0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1, 0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1, 1, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0, 1, D3DXCOLOR(0,0,1,1));


	DWORD dwFlags = 0;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	LPD3DXBUFFER	pErr	= NULL;
	
	hr = D3DXCreateEffectFromFile(	m_pDev
									,	"data/Shader.fx"
									,	NULL
									,	NULL
									,	dwFlags
									,	0
									,	&m_pEft
									,	&pErr);
	
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}

	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;


	D3DXCreateTextureFromFile(m_pDev, "Texture/Earth.bmp", &m_pTex);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pTex	);
}


INT CShaderEx::Restore()
{
	return m_pEft->OnResetDevice();
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);


	m_pDev->SetVertexDeclaration(m_pFVF);

	float	fTxDelta = 40;

	m_pEft->SetTechnique("Tech");

	m_pEft->SetFloat("m_TxD", fTxDelta);

	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->SetTexture(0, m_pTex);
		m_pDev->SetFVF(VtxDUV1::FVF);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	
	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
}


