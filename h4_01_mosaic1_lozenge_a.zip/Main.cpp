

#include "_StdAfx.h"


CMain::CMain()
{
	m_dwCreationWidth			= 800;
	m_dwCreationHeight			= 600;
	strcpy(m_strClassName, TEXT( "Shader Example" ));

	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pInput		= NULL;
	m_pGrid			= NULL;
	m_pCam			= NULL;
	m_pD3DXFont		= NULL;

	m_pShader		= NULL;
	m_pTrnd			= NULL;


	m_pField		= NULL;

	m_TreeNum		= 0;
	m_TreeMsh		= NULL;
	m_TreeMat		= NULL;

	m_SkyBox		= NULL;
}


HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(m_pInput , CMcInput		, m_hWnd);
	SAFE_NEWCREATE1(m_pCam	 , CMcCam		, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pGrid	 , CMcGrid		, m_pd3dDevice);
	SAFE_NEWCREATE1(m_pShader, CShaderEx	, m_pd3dDevice);

	// ���� Ÿ�Ͽ� �ؽ�ó ����
	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrnd, m_pd3dDevice)))
		return -1;

	
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;



	m_pField	= new CMcField;
	if(FAILED(m_pField->Create(m_pd3dDevice, "data/Field_Height10.raw", "data/map_diffuse.png", "data/map_dtail.png")))
		return -1;




	// �ҳ���
	m_TreeMsh = new CMcMesh;
	m_TreeMsh->Create(m_pd3dDevice, "xFile/pine04.x" );

	m_TreeNum	= 80;
	m_TreeMat	= new D3DXMATRIX[m_TreeNum];


	// �ҳ����� ���� ��ȯ ����� �����.
	FLOAT fW = 16.f;

	D3DXMATRIX mtR;
	D3DXMATRIX mtY;
	D3DXMATRIX mtX;

	for(int i=0; i<m_TreeNum; ++i)
	{
		FLOAT fAngleT = -20.f + rand()%41;
		FLOAT fAngleP = 0.f + rand()%360;

		fAngleT *= (D3DX_PI /180.F);
		fAngleP *= (D3DX_PI /180.F);

		D3DXMatrixRotationY(&mtY, fAngleP);
		D3DXMatrixRotationX(&mtX, fAngleT);

		mtR = mtY * mtX;

		D3DXMatrixIdentity(&m_TreeMat[i]);
		float x = 0;
		float y = 0;
		float z = 0;
		x = rand()%65 * fW;
		z = rand()%65 * fW;

		
		D3DXVECTOR3 vcIn(x,y,z);
		D3DXVECTOR3 vcOut;
		if(SUCCEEDED(m_pField->GetHeight(&vcOut, &vcIn)))
		{
			y = vcOut.y;
		}


		float fScl =1;
		fScl	= 10.f + rand()%31;
		fScl	*=.35f;

		m_TreeMat[i]._11 = fScl;
		m_TreeMat[i]._22 = fScl;
		m_TreeMat[i]._33 = fScl;

		m_TreeMat[i] *=mtR;

		m_TreeMat[i]._41 = x;
		m_TreeMat[i]._42 = y;
		m_TreeMat[i]._43 = z;
	}



	// �ҳ���
	m_SkyBox = new CMcMesh;
	m_SkyBox->Create(m_pd3dDevice, "xFile/skybox2.x" );

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pD3DXFont );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pShader	);
	SAFE_DELETE(	m_pTrnd		);



	SAFE_DELETE(	m_pField	);


	SAFE_DELETE(	m_TreeMsh	);
	SAFE_DELETE_ARRAY(	m_TreeMat	);
	SAFE_DELETE(	m_SkyBox	);

	

	return S_OK;
}



HRESULT CMain::Restore()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnResetDevice();

	m_pTrnd->OnResetDevice();


	m_pShader->Restore();



	for(int i=0; i<8; ++i)
	{
		m_pd3dDevice->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pd3dDevice->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pd3dDevice->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pD3DXFont)
		m_pD3DXFont->OnLostDevice();

	m_pTrnd->OnLostDevice();


	m_pShader->Invalidate();

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);

	// Wheel mouse...
	D3DXVECTOR3 vcD = m_pInput->GetMouseEps();

	if(vcD.z !=0.f)
		m_pCam->MoveForward(-vcD.z* .1f, 1.f);

	if(m_pInput->KeyState('W'))					// W
		m_pCam->MoveForward( 0.3F, 1.f);

	if(m_pInput->KeyState('S'))					// S
		m_pCam->MoveForward(-0.3F, 1.f);

	if(m_pInput->KeyState('A'))					// A
		m_pCam->MoveSide(-0.3F);

	if(m_pInput->KeyState('D'))					// D
		m_pCam->MoveSide(0.3F);
	

	if(m_pInput->BtnPress(1))
	{
		D3DXVECTOR3 vcDelta = m_pInput->GetMouseEps();
		m_pCam->Rotation(vcDelta);		
	}

	m_pCam->FrameMove();



	SAFE_FRMOV(	m_pGrid		);


	// ���� Ÿ�Ͽ� ��� �׸���
	m_pTrnd->BeginScene();
		this->RenderScene();
	m_pTrnd->EndScene();
	

	SAFE_FRMOV(	m_pShader	);

	sprintf( m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats	);

	return S_OK;
}


HRESULT CMain::Render()
{
	HRESULT hr=0;

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L
						);

	// ī�޶� Ŭ������ �Լ� ȣ��
	m_pCam->SetTransform();
	
	
	

	// shader ����, ��ü ȭ�鿡 �ٽ� �׸���
	LPDIRECT3DTEXTURE9	pTx = (LPDIRECT3DTEXTURE9)m_pTrnd->GetTexture();
	m_pShader->SetSceneTexture(pTx);
	SAFE_RENDER(	m_pShader	);


	m_pd3dDevice->EndScene();
	
	return S_OK;
}



void CMain::RenderScene()
{
	// ī�޶� Ŭ������ �Լ� ȣ��
	m_pCam->SetTransform();


	//�׸��带 �׸���.
//	m_pGrid->Render();


	// ������ �׸���.
	D3DLIGHT9 d3Lght;
	D3DXVECTOR3 vcLght( 1, 1, 1);

	vcLght = -vcLght;
	D3DXVec3Normalize(&vcLght, &vcLght);

	memset( &d3Lght, 0, sizeof d3Lght);
	d3Lght.Type = D3DLIGHT_DIRECTIONAL;
	d3Lght.Direction = vcLght;
	d3Lght.Range = 15000;
	d3Lght.Position = D3DXVECTOR3(100, 20, 300);
	d3Lght.Diffuse = D3DXCOLOR( 1, 1, 1, 1);

	d3Lght.Theta        = 0.3f;
    d3Lght.Phi          = 1.0f;
    d3Lght.Falloff      = 1.0f;
    d3Lght.Attenuation0 = 1.0f;


	D3DMATERIAL9	d3Mtl;
	memset(&d3Mtl, 0, sizeof d3Mtl);

	d3Mtl.Ambient = D3DXCOLOR( 1, 1, 1, 1);
	d3Mtl.Diffuse = D3DXCOLOR( 1, 1, 1, 1);
	d3Mtl.Specular = D3DXCOLOR( 1, 1, 1, 1);
	d3Mtl.Power	 =10.f;

	m_pd3dDevice->SetMaterial(&d3Mtl);

	m_pd3dDevice->SetLight( 0, &d3Lght );
	m_pd3dDevice->LightEnable( 0, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,TRUE);
	m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0xFF555555);

	

	float	fFogBgn		=  100.f;
	float	fFogEnd		= 1250.f;
	D3DXCOLOR dFogColor(0.f, .3f, .5f, 1.f);

	// Enable fog blending.
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);

	// Set the fog color.
	m_pd3dDevice->SetRenderState(D3DRS_FOGCOLOR, dFogColor);

	m_pd3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE, FALSE);

	m_pd3dDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_LINEAR);
	m_pd3dDevice->SetRenderState(D3DRS_FOGSTART, *(DWORD *)(&fFogBgn));
	m_pd3dDevice->SetRenderState(D3DRS_FOGEND,   *(DWORD *)(&fFogEnd));
	


	// ��ī�̹ڽ��� �׸���.
	D3DXMATRIX	mtSky;
	D3DXMatrixScaling(&mtSky, 400, 400, 400);
	D3DXVECTOR3 vcEye = m_pCam->GetEye();

	mtSky._41 = vcEye.x;
	mtSky._42 = vcEye.y-800;
	mtSky._43 = vcEye.z;

	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtSky);
	m_SkyBox->Render();

	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);
	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtI);



	// ������ �׸���.
	m_pField->Render();


	// ������ �׸���.
	for(int i=0; i<m_TreeNum; ++i)
	{
		m_pd3dDevice->SetTransform(D3DTS_WORLD, &m_TreeMat[i]);
		m_TreeMsh->Render();
	}


	D3DXMatrixIdentity(&mtI);
	m_pd3dDevice->SetTransform(D3DTS_WORLD, &mtI);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);


	m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
	
	RECT	rc;
	SetRect(&rc, 5, 5, m_d3dsdBackBuffer.Width - 20, 30);
	m_pD3DXFont->DrawText(NULL, m_sMsg, -1, &rc, 0, D3DCOLOR_ARGB(255,255,255,0));
}





LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}