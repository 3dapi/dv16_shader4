// McGrid.cpp: implementation of the CMcGrid class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcGrid::CMcGrid()
{
	m_pVB			= NULL;
}

CMcGrid::~CMcGrid()
{
	Destroy();

}


INT CMcGrid::Create(LPDIRECT3DDEVICE9 pDev)
{
	HRESULT hr = -1;

	m_pDev = pDev;

	m_nVtx	= 12;	// ������ ��
	

	// ���� ���۸� �����.
	hr = m_pDev->CreateVertexBuffer(
			sizeof(CMcGrid::VtxD) * m_nVtx
			, 0
			, CMcGrid::VtxD::FVF
			, D3DPOOL_MANAGED
			, &m_pVB
			, NULL);

	if( FAILED( hr))
		return -1;


	// �������� ������ ä���.
	CMcGrid::VtxD* pVtx = NULL;

	hr = m_pVB->Lock( 0, 0, (void**)&pVtx, 0 );

	if( FAILED( hr ) )
		return -1;
		
		// Y
		pVtx[ 0] = CMcGrid::VtxD( -10000.f,     0.f,     0.f, 0xffAA0000);
		pVtx[ 1] = CMcGrid::VtxD(      0.f,     0.f,     0.f, 0xffAA0000);

		pVtx[ 2] = CMcGrid::VtxD(      0.f,     0.f,     0.f, 0xffFF0000);
		pVtx[ 3] = CMcGrid::VtxD(  10000.f,     0.f,     0.f, 0xffFF0000);

		// Y
		pVtx[ 4] = CMcGrid::VtxD(      0.f,-10000.f,     0.f, 0xff00AA00);
		pVtx[ 5] = CMcGrid::VtxD(      0.f,     0.f,     0.f, 0xff00AA00);

		pVtx[ 6] = CMcGrid::VtxD(      0.f,     0.f,     0.f, 0xff00FF00);
		pVtx[ 7] = CMcGrid::VtxD(      0.f, 10000.f,     0.f, 0xff00FF00);

		// Z
		pVtx[ 8] = CMcGrid::VtxD(      0.f,     0.F,-10000.f, 0xff0000AA);
		pVtx[ 9] = CMcGrid::VtxD(      0.f,     0.f,     0.f, 0xff0000AA);

		pVtx[10] = CMcGrid::VtxD(      0.f,     0.F,     0.f, 0xff0000FF);
		pVtx[11] = CMcGrid::VtxD(      0.f,     0.F, 10000.f, 0xff0000FF);


	
	m_pVB->Unlock();


	return 0;
}

void CMcGrid::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
}

INT CMcGrid::FrameMove()
{
	return 0;
}

void CMcGrid::Render()
{
	// �������� ����.
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	
	// GPU�� ��Ʈ���� �����Ѵ�.
	m_pDev->SetStreamSource( 0, m_pVB, 0, sizeof(CMcGrid::VtxD) );

	// ��Ʈ���� FVF�� ���� �Ѵ�.
	m_pDev->SetFVF( CMcGrid::VtxD::FVF );

	// ���۹��� ���ؽ� ���۸� ������ �Ѵ�.
	m_pDev->DrawPrimitive( D3DPT_LINELIST, 0, 6 );

}