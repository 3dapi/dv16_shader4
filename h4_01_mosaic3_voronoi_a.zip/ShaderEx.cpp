// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pEft	= NULL;
	m_pFVF	= NULL;
	
	m_pTex	= NULL;

	m_pCon	= NULL;
	m_nCon	= 0;;
	m_pPos	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;
	
	m_pDev	= pDev;
	
	
	m_pVtx[0] = VtxUV1( -.9f,  .9f,	 0.f, 0.f );
	m_pVtx[1] = VtxUV1(  .9f,  .9f,	 1.f, 0.f );
	m_pVtx[2] = VtxUV1(  .9f, -.9f,	 1.f, 1.f );
	m_pVtx[3] = VtxUV1( -.9f, -.9f,	 0.f, 1.f );

	m_pVtx[0] = VtxUV1( -1.f,  1.f,	 0.f, 0.f );
	m_pVtx[1] = VtxUV1(  1.f,  1.f,	 1.f, 0.f );
	m_pVtx[2] = VtxUV1(  1.f, -1.f,	 1.f, 1.f );
	m_pVtx[3] = VtxUV1( -1.f, -1.f,	 0.f, 1.f );
	
	
	DWORD dwFlags = 0;
#if defined( _DEBUG ) || defined( DEBUG )
	dwFlags |= D3DXSHADER_DEBUG;
#endif
	
	LPD3DXBUFFER pErr = NULL;
	
	hr = D3DXCreateEffectFromFile( m_pDev
		, "data/shader.fx"
		, NULL
		, NULL
		, dwFlags
		, NULL
		, &m_pEft
		, &pErr);
	
	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", 0);
		SAFE_RELEASE(pErr);
		return -1;
	}
	
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;



	if(FAILED(D3DXCreateCylinder(m_pDev, 0, .08f, .1f, 40, 1, &m_pCon, NULL)))
		return -1;

	INT i=0;

	m_nCon= 5000;
	m_pPos = new VEC4[m_nCon];


	struct T
	{
		D3DXVECTOR3	p;
		D3DXVECTOR3 n;
	};

	DWORD dFVF = m_pCon->GetFVF();

	T* pVtx;

	int nVtx = m_pCon->GetNumVertices();

	m_pCon->LockVertexBuffer(0, (void**)&pVtx);

	for(i=0; i<nVtx; ++i)
	{
		pVtx[i].p.z +=0.05F;
	}

	m_pCon->UnlockVertexBuffer();

	for(i=0; i<m_nCon; ++i)
	{
		m_pPos[i].x = (400.f - (rand()%801) ) /400.f;
		m_pPos[i].y = (300.f - (rand()%601) ) /300.f;
		m_pPos[i].z = 0;
		m_pPos[i].w = 0;
	}


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft	);
	SAFE_RELEASE(	m_pFVF	);
	
	SAFE_RELEASE(	m_pCon	);

	SAFE_DELETE_ARRAY(	m_pPos	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	//	FOR Debug
	D3DXMATRIX mtI;
	D3DXMatrixIdentity(&mtI);

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);


	HRESULT hr;
	D3DXVECTOR4	uv;

	D3DXMatrixIdentity(&mtI);

	m_pDev->SetVertexDeclaration(m_pFVF);
	hr = m_pEft->SetTechnique("Tech");
	
	hr = m_pEft->Begin(NULL, 0);
	hr = m_pEft->BeginPass(0);

		hr = m_pEft->SetTexture("m_TxDif", m_pTex);

		for(int i=0; i<m_nCon; ++i)
		{
			mtI._41 = m_pPos[i].x;
			mtI._42 = m_pPos[i].y;

			m_pDev->SetTransform(D3DTS_WORLD, &mtI);


			// ��ġ�� [-1.1] �̾����Ƿ� ������ [0,1]�Ѵ�.
			uv = ( m_pPos[i] + D3DXVECTOR4(1,1,0,0) ) * 0.5;
			uv.y = 1 - uv.y;

			hr = m_pEft->SetVector("m_UV", &uv);

			hr = m_pEft->CommitChanges();
			m_pCon->DrawSubset(0);
		}

		D3DXMatrixIdentity(&mtI);
		m_pDev->SetTransform(D3DTS_WORLD, &mtI);

	m_pEft->EndPass();
	m_pEft->End();



	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
	
}




INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	return 0;
}


void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTex = pTx;
}

	
