// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2							VEC2;
typedef	D3DXVECTOR3							VEC3;
typedef D3DXVECTOR4							VEC4;
typedef D3DXMATRIX							MATA;

typedef LPDIRECT3DDEVICE9					PDEV;

typedef	LPD3DXEFFECT						PDEF;
typedef LPDIRECT3DVERTEXDECLARATION9		PDVD;
typedef LPDIRECT3DTEXTURE9					PDTX;


class CShaderEx
{
public:
	struct VtxDUV1
	{
		VEC3	p;
		DWORD	d;
		FLOAT	u,v;
		
		VtxDUV1()								  : p(0,0,0), d(0xFFFFFFFF){}
		VtxDUV1(  FLOAT X, FLOAT Y, FLOAT Z
			,  FLOAT U, FLOAT V, DWORD D=0XFFFFFFFF) : p(X,Y,Z), u(U), v(V), d(D){}

		enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1),};
	};

public:
	PDEV		m_pDev;				// Device

	PDVD		m_pFVF;				// Vertex Declaration
	PDEF		m_pEft;				// Effect
	VtxDUV1		m_pVtx[4];			// Vertex Buffer


	D3DSURFACE_DESC	m_DscTx;
	PDTX		m_pTex;				// Texture

	PDTX		m_pTx1;				// Texture 1
	PDTX		m_pTx2;				// Texture 2
	PDTX		m_pTx3;				// Texture 3

	void*		m_pDshow;

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif
