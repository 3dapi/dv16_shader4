// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <windows.h>
#include <mmsystem.h>
#include <atlbase.h>
#include <stdio.h>

#include <d3d9types.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <math.h>
#include <streams.h>

#include "_d3d/DXUtil.h"

#include "ShaderEx.h"


int LcStr_AnsiToUnicode(WCHAR* sDst, const char* sSrc, INT iLen )
{
	if( sDst==NULL || sSrc==NULL || iLen < 1 )
		return -1;
	
	INT nResult = MultiByteToWideChar( CP_ACP, 0, sSrc, -1, sDst, iLen );

	sDst[iLen-1] = 0;
	
	if( 0 == nResult)
		return -1;

	return 0;
}





#ifdef REGISTER_FILTERGRAPH

DWORD dwROTReg = 0xfedcba98;

HRESULT AddToROT(IUnknown *pUnkGraph) 
{
	IMoniker * pmk;
	IRunningObjectTable *pROT;
	if (FAILED(GetRunningObjectTable(0, &pROT)))
	{
		return -1;
	}
	
	WCHAR wsz[256];
	wsprintfW(wsz, L"FilterGraph %08x  pid %08x\0", (DWORD_PTR) 0, GetCurrentProcessId());
	
	HRESULT hr = CreateItemMoniker(L"!", wsz, &pmk);
	if (SUCCEEDED(hr)) 
	{
		hr = pROT->Register(ROTFLAGS_REGISTRATIONKEEPSALIVE, pUnkGraph, pmk, &dwROTReg);
		pmk->Release();
	}
	
	pROT->Release();
	return hr;
}


void RemoveFromROT(void)
{
	IRunningObjectTable *pirot=0;
	
	if (SUCCEEDED(GetRunningObjectTable(0, &pirot))) 
	{
		pirot->Revoke(dwROTReg);
		pirot->Release();
	}
}

#endif





struct __declspec(uuid("{71771540-2017-11cf-ae26-0020afd79767}")) CLSID_TxRnd;

//-----------------------------------------------------------------------------
// CTxRnd Class Declarations
//-----------------------------------------------------------------------------
class CTxRnd : public CBaseVideoRenderer
{
protected:
	LPDIRECT3DDEVICE9	m_pDev;
	LPDIRECT3DTEXTURE9	m_pTex;
	

	LONG m_lVidWidth;   // Video width
	LONG m_lVidHeight;  // Video Height
	LONG m_lVidPitch;   // Video Pitch


public:
	CTxRnd(LPUNKNOWN pUnk,HRESULT *phr);
	~CTxRnd();
	
public:
	HRESULT CheckMediaType(const CMediaType *pmt );     // Format acceptable?
	HRESULT SetMediaType(const CMediaType *pmt );       // Video format notification
	HRESULT DoRenderSample(IMediaSample *pMediaSample); // New video sample	


public:
	CShaderEx*	m_pPrn;


	void	SetDevice(LPDIRECT3DDEVICE9 pDev)	{	m_pDev = pDev;	}
	void	SetTexture(LPDIRECT3DTEXTURE9 pTex)	{	m_pTex = pTex;	}
	LPDIRECT3DTEXTURE9	GetTexture()			{	return m_pTex;	}
};






// Global DirectShow pointers

CComPtr<IGraphBuilder>  g_pGB;          // GraphBuilder
CComPtr<IMediaControl>  g_pMC;          // Media Control
CComPtr<IMediaPosition> g_pMP;          // Media Position
CComPtr<IMediaEvent>    g_pME;          // Media Event
CComPtr<IBaseFilter>    g_pRenderer;    // our custom renderer

D3DFORMAT               g_TextureFormat; // Texture format

TCHAR g_achCopy[]     = TEXT("Bitwise copy of the sample");
TCHAR g_achOffscr[]   = TEXT("Using offscreen surfaces and StretchCopy()");
TCHAR g_achDynTextr[] = TEXT("Using Dynamic Textures");
TCHAR* g_pachRenderMethod = NULL;






CTxRnd::CTxRnd( LPUNKNOWN pUnk, HRESULT *phr )
: CBaseVideoRenderer(__uuidof(CLSID_TxRnd),  NAME("Texture Renderer"), pUnk, phr)
{
	// Store and AddRef the texture for our use.
	ASSERT(phr);
	if (phr)
		*phr = S_OK;

	m_pPrn	= NULL;
	m_pTex	= NULL;
}



// CTxRnd destructor

CTxRnd::~CTxRnd()
{
	// Do nothing

	SAFE_RELEASE(	m_pTex	);
}




HRESULT CTxRnd::CheckMediaType(const CMediaType *pmt)
{
	HRESULT   hr = E_FAIL;
	VIDEOINFO *pvi=0;
	
	CheckPointer(pmt,E_POINTER);
	
	// Reject the connection if this is not a video type
	if( *pmt->FormatType() != FORMAT_VideoInfo ) {
		return E_INVALIDARG;
	}
	
	// Only accept RGB24 video
	pvi = (VIDEOINFO *)pmt->Format();
	
	if(IsEqualGUID( *pmt->Type(),    MEDIATYPE_Video)  &&
		IsEqualGUID( *pmt->Subtype(), MEDIASUBTYPE_RGB24))
	{
		hr = S_OK;
	}
	
	return hr;
}


// SetMediaType: Graph connection has been made. 

HRESULT CTxRnd::SetMediaType(const CMediaType *pmt)
{
	HRESULT hr;
	
	UINT uintWidth = 2;
	UINT uintHeight = 2;
	
	// Retrive the size of this media type
	D3DCAPS9 caps;
	VIDEOINFO *pviBmp;                      // Bitmap info header
	pviBmp = (VIDEOINFO *)pmt->Format();
	
	m_lVidWidth  = pviBmp->bmiHeader.biWidth;
	m_lVidHeight = abs(pviBmp->bmiHeader.biHeight);
	m_lVidPitch  = (m_lVidWidth * 3 + 3) & ~(3); // We are forcing RGB24
	
	// here let's check if we can use dynamic textures
	ZeroMemory( &caps, sizeof(D3DCAPS9));
	hr = m_pDev->GetDeviceCaps( &caps );
	if( caps.Caps2 & D3DCAPS2_DYNAMICTEXTURES )
	{
	}
	
	if( caps.TextureCaps & D3DPTEXTURECAPS_POW2 )
	{
		while( (LONG)uintWidth < m_lVidWidth )
		{
			uintWidth = uintWidth << 1;
		}
		while( (LONG)uintHeight < m_lVidHeight )
		{
			uintHeight = uintHeight << 1;
		}
	}
	else
	{
		uintWidth = m_lVidWidth;
		uintHeight = m_lVidHeight;
	}
	
	// Create the texture that maps to this media type
	hr = E_UNEXPECTED;

	hr = m_pDev->CreateTexture(uintWidth, uintHeight, 1, 0, D3DFMT_X8R8G8B8,D3DPOOL_MANAGED, &m_pTex, NULL);
	g_pachRenderMethod = g_achCopy;


	if( FAILED(hr))
	{
		return hr;
	}
	
	// CreateTexture can silently change the parameters on us
	D3DSURFACE_DESC ddsd;
	ZeroMemory(&ddsd, sizeof(ddsd));
	
	if ( FAILED( hr = m_pTex->GetLevelDesc( 0, &ddsd ) ) )
		return hr;
	
	
	CComPtr<IDirect3DSurface9> pSurf; 
	
	if (SUCCEEDED(hr = m_pTex->GetSurfaceLevel(0, &pSurf)))
		pSurf->GetDesc(&ddsd);
	
	// Save format info
	g_TextureFormat = ddsd.Format;
	
	if (g_TextureFormat != D3DFMT_X8R8G8B8 && g_TextureFormat != D3DFMT_A1R5G5B5)
	{
		return VFW_E_TYPE_NOT_ACCEPTED;
	}
	
	return S_OK;
}



// DoRenderSample: A sample has been delivered. Copy it to the texture.
HRESULT CTxRnd::DoRenderSample( IMediaSample * pSample )
{
	BYTE  *pBmpBuffer, *pTxtBuffer; // Bitmap buffer, texture buffer
	LONG  lTxtPitch;                // Pitch of bitmap, texture
	
	BYTE  * pbS = NULL;
	DWORD * pdwS = NULL;
	DWORD * pdwD = NULL;
	UINT row, col, dwordWidth;
	
	CheckPointer(pSample,E_POINTER);
	CheckPointer(m_pTex,E_UNEXPECTED);
	
	// Get the video bitmap buffer
	pSample->GetPointer( &pBmpBuffer );
	
	// Lock the Texture
	D3DLOCKED_RECT d3dlr;

	if (FAILED(m_pTex->LockRect(0, &d3dlr, 0, 0)))
		return -1;

	// Get the texture buffer & pitch
	pTxtBuffer = static_cast<byte *>(d3dlr.pBits);
	lTxtPitch = d3dlr.Pitch;
	
	
	// Copy the bits    
	
	if (g_TextureFormat == D3DFMT_X8R8G8B8) 
	{
		// Instead of copying data bytewise, we use DWORD alignment here.
		// We also unroll loop by copying 4 pixels at once.
		//
		// original BYTE array is [b0][g0][r0][b1][g1][r1][b2][g2][r2][b3][g3][r3]
		//
		// aligned DWORD array is     [b1 r0 g0 b0][g2 b2 r1 g1][r3 g3 b3 r2]
		//
		// We want to transform it to [ff r0 g0 b0][ff r1 g1 b1][ff r2 g2 b2][ff r3 b3 g3]
		// below, bitwise operations do exactly this.
		
		dwordWidth = m_lVidWidth / 4; // aligned width of the row, in DWORDS
		// (pixel by 3 bytes over sizeof(DWORD))
		
		for( row = 0; row< (UINT)m_lVidHeight; row++)
		{
			pdwS = ( DWORD*)pBmpBuffer;
			pdwD = ( DWORD*)pTxtBuffer;
			
			for( col = 0; col < dwordWidth; col ++ )
			{
				pdwD[0] =  pdwS[0] | 0xFF000000;
				pdwD[1] = ((pdwS[1]<<8)  | 0xFF000000) | (pdwS[0]>>24);
				pdwD[2] = ((pdwS[2]<<16) | 0xFF000000) | (pdwS[1]>>16);
				pdwD[3] = 0xFF000000 | (pdwS[2]>>8);
				pdwD +=4;
				pdwS +=3;
			}
			
			// we might have remaining (misaligned) bytes here
			pbS = (BYTE*) pdwS;
			for( col = 0; col < (UINT)m_lVidWidth % 4; col++)
			{
				*pdwD = 0xFF000000     |
					(pbS[2] << 16) |
					(pbS[1] <<  8) |
					(pbS[0]);
				pdwD++;
				pbS += 3;           
			}
			
			pBmpBuffer  += m_lVidPitch;
			pTxtBuffer += lTxtPitch;
		}// for rows
	}
	
	if (g_TextureFormat == D3DFMT_A1R5G5B5) 
	{
		for(int y = 0; y < m_lVidHeight; y++ ) 
		{
			BYTE *pBmpBufferOld = pBmpBuffer;
			BYTE *pTxtBufferOld = pTxtBuffer;   
			
			for (int x = 0; x < m_lVidWidth; x++) 
			{
				*(WORD *)pTxtBuffer = (WORD)
					(0x8000 +
					((pBmpBuffer[2] & 0xF8) << 7) +
					((pBmpBuffer[1] & 0xF8) << 2) +
					(pBmpBuffer[0] >> 3));
				
				pTxtBuffer += 2;
				pBmpBuffer += 3;
			}
			
			pBmpBuffer = pBmpBufferOld + m_lVidPitch;
			pTxtBuffer = pTxtBufferOld + lTxtPitch;
		}
	}
	
	// Unlock the Texture
	if (FAILED(m_pTex->UnlockRect(0)))
		return -1;
	
	return S_OK;
}








CShaderEx::CShaderEx()
{
	CoInitialize (NULL);

	m_pDev	= NULL;
	m_pEft	= NULL;
	
	m_pTex	= NULL;
	m_pTx1	= NULL;
	m_pTx2	= NULL;
	m_pTx3	= NULL;

	m_pDshow=NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();

	CoUninitialize();
}


INT CShaderEx::Create(PDEV pDev)
{
	HWND	hWnd;
	HRESULT	hr=0;

	m_pDev	= pDev;

	////////////////////////////////////////////////////////////////////////////
	// Base Code
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);

	hWnd = ppm.hFocusWindow;

	m_pVtx[0] = VtxDUV1(-1, 1,  0,  0, 1, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxDUV1( 1, 1,  0,  1, 1, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxDUV1( 1,-1,  0,  1, 0, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxDUV1(-1,-1,  0,  0, 0, D3DXCOLOR(0,0,1,1));

	DWORD dwFlags = 0;
	LPD3DXBUFFER	pErr	= NULL;

	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif


	//�ڵ� ������
	hr = D3DXCreateEffectFromFile(	m_pDev
									,	"data/Shader.fx"
									,	NULL
									,	NULL
									,	dwFlags
									,	0
									,	&m_pEft
									,	&pErr);
	
	if ( FAILED(hr) )
	{
		if(pErr)
		{
			MessageBox( hWnd, (char*)pErr->GetBufferPointer(), "Err", 0);
			pErr->Release();	pErr = NULL;
		}

		return -1;
	}

	// ���� ������
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, vertex_decl);
	
	if( FAILED( hr = m_pDev->CreateVertexDeclaration(vertex_decl, &m_pFVF)))
		return -1;

	//
	////////////////////////////////////////////////////////////////////////////



	D3DXCreateTextureFromFile(m_pDev, "Texture/Lvl1.bmp", &m_pTx1);
	D3DXCreateTextureFromFile(m_pDev, "Texture/Lvl2.bmp", &m_pTx2);
	D3DXCreateTextureFromFile(m_pDev, "Texture/Lvl3.bmp", &m_pTx3);



	
	CComPtr<IBaseFilter>    pFSrc;          // Source Filter
	CComPtr<IPin>           pFSrcPinOut;    // Source Filter Output Pin   
	CTxRnd			      *pCTR=0;			// DirectShow Texture renderer
	
	// Create the filter graph
	if (FAILED(g_pGB.CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC)))
		return -1;

	
#ifdef REGISTER_FILTERGRAPH
	AddToROT(g_pGB);
#endif
	
	// Create the Texture Renderer object
	pCTR = new CTxRnd(NULL, &hr);
	if (FAILED(hr) || !pCTR)
		return -1;


	pCTR->SetDevice(m_pDev);
	
	// Get a pointer to the IBaseFilter on the TxRnd, add it to graph
	g_pRenderer = pCTR;
	if (FAILED(hr = g_pGB->AddFilter(g_pRenderer, L"TEXTURERENDERER")))
		return hr;

	
	TCHAR strFileName[MAX_PATH]={0};
	WCHAR wFileName[MAX_PATH]={0};
	
	lstrcat( strFileName, "data/skii.avi" );
	USES_CONVERSION;
	wcsncpy(wFileName, T2W(strFileName), NUMELMS(wFileName));

//	LcStr_AnsiToUnicode(wFileName, strFileName, strlen(strFileName)+2);
	
	// Add the source filter to the graph.
	hr = g_pGB->AddSourceFilter (wFileName, L"SOURCE", &pFSrc);


	
	// If the media file was not found, inform the user.
	if (hr == VFW_E_NOT_FOUND)
		return hr;

	else if(FAILED(hr))
		return hr;
	
	if (FAILED(hr = pFSrc->FindPin(L"Output", &pFSrcPinOut)))
		return hr;


	
#ifdef NO_AUDIO_RENDERER
	
	// If no audio component is desired, directly connect the two video pins
	// instead of allowing the Filter Graph Manager to render all pins.
	
	CComPtr<IPin> pFTRPinIn;      // Texture Renderer Input Pin

	

	// Find the source's output pin and the renderer's input pin
	if (FAILED(hr = pFTR->FindPin(L"In", &pFTRPinIn)))
		return hr;
	
	// Connect these two filters
	if (FAILED(hr = g_pGB->Connect(pFSrcPinOut, pFTRPinIn)))
		return hr;

	
#else
	
	// Render the source filter's output pin.  The Filter Graph Manager
	// will connect the video stream to the loaded CTxRnd
	// and will load and connect an audio renderer (if needed).
	
	if (FAILED(hr = g_pGB->Render(pFSrcPinOut)))
		return hr;

	
#endif


	m_pTex = pCTR->GetTexture();
	
	// Get the graph's media control, event & position interfaces
	g_pGB.QueryInterface(&g_pMC);
	g_pGB.QueryInterface(&g_pMP);
	g_pGB.QueryInterface(&g_pME);
	
	// Start the graph running;
	if (FAILED(hr = g_pMC->Run()))
		return hr;


	return 0;
}




void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pEft	);


#ifdef REGISTER_FILTERGRAPH
	// Pull graph from Running Object Table (Debug)
	RemoveFromROT();
#endif
	
	// Shut down the graph
	if (!(!g_pMC)) g_pMC->Stop();
	
	if (!(!g_pMC)) g_pMC.Release();
	if (!(!g_pME)) g_pME.Release();
	if (!(!g_pMP)) g_pMP.Release();
	if (!(!g_pGB)) g_pGB.Release();
	if (!(!g_pRenderer)) g_pRenderer.Release();



	SAFE_RELEASE(	m_pTx1	);
	SAFE_RELEASE(	m_pTx2	);
	SAFE_RELEASE(	m_pTx3	);
}


INT CShaderEx::Restore()
{
	if(m_pTex)
		m_pTex->GetLevelDesc(0, &m_DscTx);

	return m_pEft->OnResetDevice();
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();
}


INT CShaderEx::FrameMove()
{
	long lEventCode;
	long lParam1;
	long lParam2;
	HRESULT hr;
	
	if (!g_pME)
		return 0;
	
	// Check for completion events
	hr = g_pME->GetEvent(&lEventCode, (LONG_PTR *) &lParam1, (LONG_PTR *) &lParam2, 0);
	if (SUCCEEDED(hr))
	{
		// If we have reached the end of the media file, reset to beginning
		if (EC_COMPLETE == lEventCode) 
		{
			hr = g_pMP->put_CurrentPosition(0);
		}
		
		// Free any memory associated with this event
		hr = g_pME->FreeEventParams(lEventCode, lParam1, lParam2);
	}

	return 0;
}


void CShaderEx::Render()
{
	static D3DXMATRIX mtI(1,0,0,0,    0,1,0,0,    0,0,1,0,    0,0,0,1);
	HRESULT	hr = 0;

	// ��ȯ ����� �ʱ�ȭ
	////////////////////////////////////////////////////////////////////////////
	// for Test

	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetTransform(D3DTS_VIEW, &mtI);
	m_pDev->SetTransform(D3DTS_PROJECTION, &mtI);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE , FALSE);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP  , D3DTOP_MODULATE);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	for(int i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}

// �����Լ� ���������ο��� �̹����� ��µǴ� �� Ȯ��
//	m_pDev->SetTexture(0, m_pTex);
//	m_pDev->SetFVF(VtxDUV1::FVF);
//	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	//
	////////////////////////////////////////////////////////////////////////////


	m_pDev->SetVertexDeclaration(m_pFVF);
	m_pEft->SetTechnique("Tech");


	m_pEft->Begin(NULL, 0);
	m_pEft->BeginPass(0);

		m_pDev->SetTexture(0, m_pTex);
		m_pDev->SetTexture(1, m_pTx1);
		m_pDev->SetTexture(2, m_pTx2);
		m_pDev->SetTexture(3, m_pTx3);

		m_pDev->SetFVF(VtxDUV1::FVF);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();


	m_pDev->SetTexture(0, NULL);
	m_pDev->SetTexture(1, NULL);
	m_pDev->SetTexture(2, NULL);
	m_pDev->SetTexture(3, NULL);

	m_pDev->SetVertexDeclaration( NULL);
	m_pDev->SetVertexShader( NULL);
	m_pDev->SetPixelShader( NULL);
}



