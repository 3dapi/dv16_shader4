// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev		= NULL;
	m_pEft		= NULL;
	m_pFVF		= NULL;
	
	m_pTex		= NULL;


	m_pTrnd	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	m_pVtx[0] = VtxDUV1( -1, 1,  0,  0, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[1] = VtxDUV1(  1, 1,  0,  1, 0, D3DXCOLOR(1,1,1,1));
	m_pVtx[2] = VtxDUV1(  1,-1,  0,  1, 1, D3DXCOLOR(1,1,1,1));
	m_pVtx[3] = VtxDUV1( -1,-1,  0,  0, 1, D3DXCOLOR(1,1,1,1));


	
	
	
	char	sShaderFile[]="data/hlsl.fx";
	LPD3DXBUFFER	pError	= NULL;
	DWORD		dFlag=0;

	#if defined( _DEBUG ) || defined( DEBUG )
	dFlag |= D3DXSHADER_DEBUG;
	#endif

	// ������
	hr = D3DXCreateEffectFromFile(
								  m_pDev
								, sShaderFile
								, NULL
								, NULL
								, dFlag
								, NULL
								, &m_pEft
								, &pError);
	if(FAILED(hr))
	{
		MessageBox(GetActiveWindow()
					, (char*)pError->GetBufferPointer()
					, "Error", 0);
		return -1;
	}
	
	// ���� ���� ����
	D3DVERTEXELEMENT9 pVertexElement[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxDUV1::FVF, pVertexElement);
	m_pDev->CreateVertexDeclaration(pVertexElement, &m_pFVF);

	D3DXCreateTextureFromFile(m_pDev, "Texture/Earth.bmp", &m_pTex);




	m_TexW = 800;
	m_TexH = 600;


	// ���� Ÿ�Ͽ� �ؽ�ó ����
	if(FAILED(LcD3D_CreateRenderTarget(NULL, &m_pTrnd, m_pDev, m_TexW,m_TexH)))
		return -1;


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pEft		);
	SAFE_RELEASE(	m_pFVF		);
	
	SAFE_RELEASE(	m_pTex		);


	SAFE_DELETE(	m_pTrnd		);
}


INT CShaderEx::FrameMove()
{
	HRESULT hr;

	PDTX	pTx =NULL;
	int i;


	for(i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	}


	m_pTrnd->BeginScene();

	hr = m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00006699, 1.0f, 0L );
	
	
	pTx= m_pTex;

	m_pDev->SetVertexDeclaration(m_pFVF);

	hr = m_pDev->SetTexture(0, pTx);
	
	
	hr = m_pEft->SetTechnique("Tech");
	hr = m_pEft->SetFloat("m_TexW", m_TexW);
	hr = m_pEft->SetFloat("m_TexH", m_TexH);



	hr = m_pEft->Begin(NULL, 0);
	hr = m_pEft->BeginPass(0);

		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

	m_pEft->EndPass();
	m_pEft->End();

	m_pTrnd->EndScene();

	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	return 0;
}


void CShaderEx::Render()
{
	int i=0;
	HRESULT hr=0;


	VtxDUV1	pVx0[4];
	pVx0[0] = VtxDUV1( -1, 1,  0,  0.0f, 0, D3DXCOLOR(1,1,1,1));
	pVx0[1] = VtxDUV1(  0, 1,  0,  0.5f, 0, D3DXCOLOR(1,1,1,1));
	pVx0[2] = VtxDUV1(  0,-1,  0,  0.5f, 1, D3DXCOLOR(1,1,1,1));
	pVx0[3] = VtxDUV1( -1,-1,  0,  0.0f, 1, D3DXCOLOR(1,1,1,1));

	m_pDev->SetTexture(0, m_pTex);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVx0, sizeof(VtxDUV1));



	VtxDUV1	pVx1[4];
	pVx1[0] = VtxDUV1(  0, 1,  0,  0.5f, 0, D3DXCOLOR(1,1,1,1));
	pVx1[1] = VtxDUV1(  1, 1,  0,  1.0f, 0, D3DXCOLOR(1,1,1,1));
	pVx1[2] = VtxDUV1(  1,-1,  0,  1.0f, 1, D3DXCOLOR(1,1,1,1));
	pVx1[3] = VtxDUV1(  0,-1,  0,  0.5f, 1, D3DXCOLOR(1,1,1,1));

	PDTX pTex = (PDTX)m_pTrnd->GetTexture();
	m_pDev->SetTexture(0, pTex);
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVx1, sizeof(VtxDUV1));


	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
}


INT CShaderEx::Restore()
{
	m_pEft->OnResetDevice();

	m_pTrnd->OnResetDevice();

	return 0;
}

void CShaderEx::Invalidate()
{
	m_pEft->OnLostDevice();

	m_pTrnd->OnLostDevice();
}